<?php

include 'nutrition.php';
include 'search.php';
include 'recipe-list.php';
include 'recipe-categories.php';
include 'recipe-card.php';
