<?php
/**
 * Plugin Name: Total Recipe Generator
 * Author:      SaurabhSharma
 * Author URI: 	http://codecanyon.net/user/saurabhsharma
 * Version:     1.6.7
 * Text Domain: trg
 * Domain Path: /languages/
 * Description: A Visual Composer add-on for generating Recipe content with rich schema and nutrition facts.
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Total_Recipe_Generator' ) ) {

	class Total_Recipe_Generator {

		public $vct_prefix = 'trg';

		function __construct() {

			// Include required files
			add_action( 'plugins_loaded', array( &$this, 'trg_includes' ) );

			// Load translation, scripts and shortcodes
			add_action( 'init', array( &$this, 'trg_init' ) );

			// VC Specific
			add_action( 'vc_before_init', array( &$this, 'trg_map_shortcode_to_vc' ) );
			add_action( 'after_setup_theme', array( &$this, 'trg_add_vc_templates' ) );
			add_action( 'admin_notices',  array( &$this, 'trg_install_vc_notice' ) );
			add_action( 'admin_enqueue_scripts', array( &$this, 'trg_admin_scripts' ) );
			
			// Custom CSS in head
			add_action( 'wp_head',  array( &$this, 'trg_add_global_css' ) );
			add_action( 'wp_head',  array( &$this, 'trg_add_css_to_front' ) );
			add_filter( 'wp_kses_allowed_html', array( &$this, 'trg_allow_iframes_in_post' ) );
		}

		function trg_allow_iframes_in_post( $allowedtags ) {
			if ( ! current_user_can( 'publish_posts' ) ) return $allowedtags;
			// Allow iframes and the following attributes
			$allowedtags['iframe'] = array(
				'align' => true,
				'width' => true,
				'height' => true,
				'frameborder' => true,
				'name' => true,
				'src' => true,
				'id' => true,
				'class' => true,
				'style' => true,
				'scrolling' => true,
				'marginwidth' => true,
				'marginheight' => true,
			);
			return $allowedtags;
		}		
		
		// Enqueue admin scripts and styles
		function trg_admin_scripts() {
			wp_enqueue_style( 'trg-admin-css', plugin_dir_url( __FILE__ ) . 'assets/css/trg_admin.css' );
		}		

		// Show notice if Visual Composer not installed
		function trg_install_vc_notice() {
			if ( ! class_exists( 'Vc_Manager' ) ) {
				echo sprintf( '<div class="error"><p>%s</p></div>', esc_attr__( 'Total Recipe Generator plugin requires Visual Composer plugin to work correctly. Kindly install and activate WPBakery Visual Composer plugin.', 'trg' ) );
			}
			else {
				return;
			}
		}

		// Include required files
		function trg_includes() {
			$plugin_dir = trailingslashit( plugin_dir_path( __FILE__ ) );
			require_once( $plugin_dir . 'includes/class.settings-api.php' );
			require_once( $plugin_dir . 'includes/settings.php' );			
			require_once( $plugin_dir . 'includes/BFI_Thumb.php' );

			if ( class_exists ( 'Vc_Manager' ) ) {
				require_once( $plugin_dir . 'includes/trg_functions.php' );
			}
		}

		// Add Global CSS from plugin settings
		function trg_add_global_css() {
			$colors = get_option( 'trg_display' );
			$css = '';
			// Icon color
			if ( isset( $colors ) && ! empty( $colors ) ) {
				if ( '' != $colors['icon_color'] ) {
					$css .= '.recipe-heading:before{color:' . $colors['icon_color'] . ' ;}';
				}
				if ( '' != $colors['heading_color'] ) {
					$css .= '.recipe-heading{color:' . $colors['heading_color'] . ' !important;}';
				}

				if ( '' != $colors['label_color'] ) {
					$css .= '.info-board>li .ib-label,.cuisine-meta .cm-label{color:' . $colors['label_color'] . ';}';
				}

				if ( '' != $colors['highlights'] ) {
					$css .= '.info-board>li .ib-value{color:' . $colors['highlights'] . ';}';
				}

				if ( '' != $colors['tick_color'] ) {
					$css .= '.ing-list>li:before{color:' . $colors['tick_color'] . ';}';
				}

				if ( '' != $colors['count_color'] ) {
					$css .= '.step-num{color:' . $colors['count_color'] . ';}';
				}

				// Tags links CSS
				if ( '' != $colors['tags_bg'] || '' != $colors['tags_color'] ) {
					$css .= '.cuisine-meta .cm-value:not(.link-enabled),.cuisine-meta .cm-value a{';
					$css .= ( '' != $colors['tags_bg'] ) ? 'background-color:' . $colors['tags_bg'] . ' !important;' : '';
					$css .= ( '' != $colors['tags_color'] ) ? 'color:' . $colors['tags_color'] . ' !important;' : '';
					$css .= 'box-shadow:none !important;}';
				}

				// Tags links hover CSS
				if ( '' != $colors['tags_bg_hover'] || '' != $colors['tags_color_hover'] ) {
					$css .= '.cuisine-meta .cm-value a:hover,.cuisine-meta .cm-value a:active{';
					$css .= ( '' != $colors['tags_bg_hover'] ) ? 'background-color:' . $colors['tags_bg_hover'] . ' !important;' : '';
					$css .= ( '' != $colors['tags_color_hover'] ) ? 'color:' . $colors['tags_color_hover'] . ' !important;' : '';
					$css .= '}';
				}
			}
			if ( $css ) {
				echo '<style id="trg_global_css" type="text/css"> ' . $css . '</style>';
			}
		}		
		
		// Adds custom CSS to front end
		function trg_add_css_to_front() {
			global $post;
			$sc_atts = array();
			$css = '';
			$export = array (
				'trg_css_count' => 1,
				'icon_color' => '',
				'heading_color' => '',
				'tags_bg' => '',
				'tags_color' => '',
				'tags_bg_hover' => '',
				'tags_color_hover' => '',
				'label_color' => '',
				'highlights' => '',
				'count_color' => '',
				'tick_color' => ''
			);

			if ( isset( $post->post_content ) ) {
				preg_match_all('/\[trg_recipe (.*?)\]/s', $post->post_content, $matches );
			}

			// CSS for [trg] shortcode
			if ( isset( $matches ) && is_array( $matches ) && is_array( $matches[1] ) ) {			
				$i = 1;
				foreach( $matches[1] as $match ) {
					$sc_atts = shortcode_parse_atts( $match );
					
					foreach( $export as $key => $val ) {
						$export[ $key ] = array_key_exists( $key, $sc_atts ) ? $sc_atts[ $key ] : '';
					}
					$export['trg_css_count'] = $i;				
					$css .= $this->trg_make_css( $export, 'trg_recipe' );
					$i++;
				}			
			}
			
			echo '<style type="text/css" id="trg_custom_css">' . strip_tags( $css ) . '</style>';		
		}
		
		// Make proper CSS markup
		function trg_make_css( $vars = array(), $type = 'trg_recipe' ) {
			extract( $vars );
			$css = '';
			
			if ( 'trg_recipe' == $type ) {
				
				// Icon color
				if ( '' != $icon_color ) {
					$css .= '.trg_custom_css_' . $trg_css_count . ' .recipe-heading:before{color:' . $icon_color . ' ;}';
				}
				
				if ( '' != $heading_color ) {
					$css .= '.trg_custom_css_' . $trg_css_count . ' .recipe-heading{color:' . $heading_color . ' !important;}';
				}
				
				if ( '' != $label_color ) {
					$css .= '.trg_custom_css_' . $trg_css_count . ' .info-board>li .ib-label,.trg_custom_css_' . $trg_css_count . ' .cuisine-meta .cm-label{color:' . $label_color . ';}';
				}
				
				if ( '' != $highlights ) {
					$css .= '.trg_custom_css_' . $trg_css_count . ' .info-board>li .ib-value{color:' . $highlights . ';}';
				}
				
				if ( '' != $tick_color ) {
					$css .= '.trg_custom_css_' . $trg_css_count . ' .ing-list>li:before{color:' . $tick_color . ';}';
				}
				
				if ( '' != $count_color ) {
					$css .= '.trg_custom_css_' . $trg_css_count . ' .step-num{color:' . $count_color . ';}';
				}
				
				// Tags links CSS
				if ( '' != $tags_bg || '' != $tags_color ) {
					$css .= '.trg_custom_css_' . $trg_css_count . ' .cuisine-meta .cm-value:not(.link-enabled),.trg_custom_css_' . $trg_css_count . ' .cuisine-meta .cm-value a{';
					$css .= ( '' != $tags_bg ) ? 'background-color:' . $tags_bg . ' !important;' : '';
					$css .= ( '' != $tags_color ) ? 'color:' . $tags_color . ' !important;' : '';
					$css .= 'box-shadow:none !important;}';
				}
				
				// Tags links hover CSS
				if ( '' != $tags_bg_hover || '' != $tags_color_hover ) {
					$css .= '.trg_custom_css_' . $trg_css_count . ' .cuisine-meta .cm-value a:hover,.trg_custom_css_' . $trg_css_count . ' .cuisine-meta .cm-value a:active{';
					$css .= ( '' != $tags_bg_hover ) ? 'background-color:' . $tags_bg_hover . ' !important;' : '';
					$css .= ( '' != $tags_color_hover ) ? 'color:' . $tags_color_hover . ' !important;' : '';
					$css .= '}';
				}
				
			}			
			return $css;
		}		

		// Init function
		function trg_init() {

			// Translation
			load_plugin_textdomain( 'trg', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );

			if ( ! is_admin() ) {

				wp_enqueue_style( 'trg-plugin-css', plugin_dir_url( __FILE__ ) . 'assets/css/trg_frontend.css', array(), null );

				if ( is_rtl() ) {
					wp_register_style( 'trg-plugin-rtl', plugin_dir_url( __FILE__ ) . 'assets/css/rtl_trg_frontend.css', array(), null );
					wp_enqueue_style( 'trg-plugin-rtl' );
				}

				// JavaScript files
				wp_enqueue_script( 'trg-plugin-functions', plugin_dir_url( __FILE__ ) . 'assets/js/trg_frontend.js', array( 'jquery' ), '', true );
				wp_localize_script('trg-plugin-functions', 'trg_localize', array(
				    'plugins_url' => plugins_url() . '/total-recipe-generator'
				));
			}

			// Add shortcodes
			add_shortcode( 'trg_recipe', array( $this, 'trg_recipe' ) );
			add_shortcode( 'trg_recipe_method', array( $this, 'trg_recipe_method' ) );
			add_shortcode( 'trg_image', array( $this, 'trg_image' ) );
			add_shortcode( 'trg_title', array( $this, 'trg_title' ) );

		}

		// Map shortcodes to Visual Composer
		function trg_map_shortcode_to_vc() {

			// Let plugin text domain load for vc_map
			load_plugin_textdomain( 'trg', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
			
			// [trg_recipe]
			vc_map(
				array(
					'name' => __( 'Total Recipe Generator', 'trg' ),
					'base' => 'trg_recipe',
					'icon' =>  plugin_dir_url( __FILE__ ) . 'assets/images/trg_icon.svg',
					//'is_container' => true,
					'show_settings_on_create' => false,
					'as_parent' => array(
						'only' => 'trg_recipe_method',
					),
					'content_element' => true,
					'category' => __( 'Content', 'trg' ),
					'description' => __( 'Create recipe content with nutrition facts', 'trg' ),
					'params' => array(

						// General Tab
						array(
							'heading' => __( 'Recipe Name', 'trg' ),
							'param_name' => 'name_src',
							'type' => 'dropdown',
							'value' => array(
								__( 'Use Post Title', 'trg' ) => 'post_title',
								__( 'Custom Name', 'trg' ) => 'custom'
							),
							'std' => 'post_title',
							'description' => __( 'Choose a name source for Recipe', 'trg' ),
							'group' => __( 'General', 'trg' )
						),

						array(
							'heading' => __( 'Custom Recipe Name', 'trg' ),
							'param_name' => 'name_txt',
							'type' => 'textfield',
							'std' => '',
							'description' => __( 'Provide a name for the recipe', 'trg' ),
							'dependency' => array(
								'element' => 'name_src',
								'value' => 'custom'
							),
							'group' => __( 'General', 'trg' )
						),
						
						array(
							'heading' => __( 'Recipe Template', 'trg' ),
							'type' => 'dropdown',
							'param_name' => 'template',
							'value' => array(
								__( 'Standard (1 col)', 'trg' ) => 'recipe',
								__( 'Ingredients + Method (2 col)', 'trg' ) => 'recipe2',
								__( 'Method + Ingredients (2 col)', 'trg' ) => 'recipe3'
							),
							'std' => '',
							'description' => __( 'Select a recipe template', 'trg' ),
							'group' => __( 'General', 'trg' )
						),

						array(
							'heading' => __( 'Recipe image', 'trg' ),
							'type' => 'dropdown',
							'param_name' => 'img_src',
							'value' => array(
									__( 'Use featured image', 'trg' ) => 'featured',
									__( 'Select from media library', 'trg' ) => 'media_lib',
									__( 'Use external url', 'trg' ) => 'ext'
							),
							'std' => 'featured',
							'description' => __( 'Select image source', 'trg' ),
							'group' => __( 'General', 'trg' )
						),

						array(
							'param_name' => 'img_lib',
							'heading' => __( 'Add recipe image', 'trg' ),
							'type' => 'attach_image',
							'description' => __( 'Add a recipe image', 'trg' ),
							'dependency' => array(
								'element' => 'img_src',
								'value' => 'media_lib'
							),
							'group' => __( 'General', 'trg' )
						),

						array(
							'param_name' => 'img_ext',
							'heading' => __( 'Add external image URL', 'trg' ),
							'type' => 'textfield',
							'description' => __( 'Add external image URL', 'trg' ),
							'dependency' => array(
								'element'    => 'img_src',
								'value' => 'ext'
							),
							'group' => __( 'General', 'trg' )
						),

						array(
							'heading' => __( 'Image alt text', 'trg' ),
							'param_name' => 'img_alt',
							'type' => 'textfield',
							'std' => '',
							'description' => __( 'Provide an alternative text for image', 'trg' ),
							'group' => __( 'General', 'trg' )
						),

						array(
							'heading' => __( 'Image caption', 'trg' ),
							'param_name' => 'img_caption',
							'type' => 'textfield',
							'std' => '',
							'description' => __( 'Provide a caption for image', 'trg' ),
							'group' => __( 'General', 'trg' )
						),

						array(
							'heading' => __( 'Image width', 'trg' ),
							'param_name' => 'imgwidth',
							'type' => 'textfield_num',
							'value' => '3',
							'min' => '10',
							'max' => '2000',
							'std' => '',
							'description' => __( 'Provide image width (in px, without unit) for the recipe image.', 'trg' ),
							'dependency' => array(
								'element'    => 'img_src',
								'value_not_equal_to' => 'ext'
							),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							'group' => __( 'General', 'trg' )
						),

						array(
							'heading' => __( 'Image height', 'trg' ),
							'param_name' => 'imgheight',
							'type' => 'textfield_num',
							'value' => '',
							'min' => '10',
							'max' => '2000',
							'std' => '',
							'description' => __( 'Provide image height (in px, without unit) for the recipe image.', 'trg' ),
							'dependency' => array(
								'element'    => 'img_src',
								'value_not_equal_to' => 'ext'
							),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							'group' => __( 'General', 'trg' )
						),

						array(
							'heading' => __( 'Image quality', 'trg' ),
							'param_name' => 'imgquality',
							'type' => 'textfield_num',
							'value' => '80',
							'min' => '1',
							'max' => '100',
							'std' => '80',
							'description' => __( 'Provide image quality (in %, without unit) for the thumbnail image.', 'trg' ),
							'dependency' => array(
								'element'    => 'img_src',
								'value_not_equal_to' => 'ext'
							),
							'group' => __( 'General', 'trg' )
						),

						array(
							'param_name' => 'imgcrop',
							'heading' => __( 'Image Crop', 'trg' ),
							'type' => 'checkbox',
							'value' => array( __( 'Hard crop images', 'trg' ) => 'true' ),
							'description' => __( 'Check to enable hard cropping of thumbnail image.', 'trg' ),
							'dependency' => array(
								'element'    => 'img_src',
								'value_not_equal_to' => 'ext'
							),
							'group' => __( 'General', 'trg' )
						),

						array(
							'heading' => __( 'Image align', 'trg' ),
							'type' => 'dropdown',
							'param_name' => 'img_align',
							'value' => array(
									__( 'None', 'trg' )  => 'none',
									__( 'Left', 'trg' )  => 'left',
									__( 'Right', 'trg' )  => 'right',
									__( 'Center', 'trg' )  => 'center'
							),
							'std' => 'none',
							'description' => __( 'Select image alignment. Image will be aligned with respect to the summary text.', 'trg' ),
							'group' => __( 'General', 'trg' )
						),

						array(
							'heading' => __( 'Recipe Summary', 'trg' ),
							'param_name' => 'summary',
							'type' => 'textarea',
							'std' => 'This is a recipe summary text. It can be a small excerpt about what you are going to cook.',
							'description' => __( 'Provide a short summary or description of your recipe', 'trg' ),
							'group' => __( 'General', 'trg' )
						),

						array(
							'heading' => __( 'Method Section Heading', 'trg' ),
							'param_name' => 'method_heading',
							'type' => 'textfield',
							'std' => __( 'Method', 'trg' ),
							'description' => __( 'Provide a heading for method section', 'trg' ),
							'group' => __( 'General', 'trg' )
						),

						array(
							'heading' => __( 'Other notes', 'trg' ),
							'param_name' => 'other_notes',
							'type' => 'textarea',
							'std' => 'This is an extra note from author. This can be any tip, suggestion or fact related to the recipe.',
							'description' => __( 'Provide extra notes to be shown at the end of recipe', 'trg' ),
							'group' => __( 'General', 'trg' )
						),
						
						array(
							'heading' => __( 'Ad Spot 1', 'trg' ),
							'param_name' => 'ad_spot_1',
							'type' => 'textarea_raw_html',
							'std' => '',
							'description' => __( 'Advertisement spot before ingredients section. You can use custom HTML or ad script in this field.', 'trg' ),
							'group' => __( 'General', 'trg' )
						),
						
						array(
							'heading' => __( 'Ad Spot 2', 'trg' ),
							'param_name' => 'ad_spot_2',
							'type' => 'textarea_raw_html',
							'std' => '',
							'description' => __( 'Advertisement spot before method steps section. You can use custom HTML or ad script in this field.', 'trg' ),
							'group' => __( 'General', 'trg' )
						),
						
						array(
							'heading' => __( 'Ad Spot 3', 'trg' ),
							'param_name' => 'ad_spot_3',
							'type' => 'textarea_raw_html',
							'std' => '',
							'description' => __( 'Advertisement spot after nutrition facts section. You can use custom HTML or ad script in this field.', 'trg' ),
							'group' => __( 'General', 'trg' )
						),

						// Recipe Meta tab
						array(
							'heading' => __( 'Recipe Cuisine', 'trg' ),
							'type' => 'dropdown_multiple',
							'param_name' => 'recipe_cuisine',
							'value' => apply_filters( 'trg_cuisine_list', array(
									__( 'American', 'trg' ) => __( 'American', 'trg' ),
									__( 'Chinese', 'trg' ) => __( 'Chinese', 'trg' ),
									__( 'French', 'trg' ) => __( 'French', 'trg' ),
									__( 'Indian', 'trg' ) => __( 'Indian', 'trg' ),
									__( 'Italian', 'trg' ) => __( 'Italian', 'trg' ),
									__( 'Japanese', 'trg' ) => __( 'Japanese', 'trg' ),
									__( 'Mediterranean', 'trg' ) => __( 'Mediterranean', 'trg' ),
									__( 'Mexican', 'trg' ) => __( 'Mexican', 'trg' )
								)
							),
							'std' => '',
							'description' => __( 'Select recipe cuisine from above list or use custom field below', 'trg' ),
							'group' => __( 'Recipe Meta', 'trg' )
						),

						array(
							'heading' => __( 'Other recipe cuisine', 'trg' ),
							'param_name' => 'recipe_cuisine_other',
							'type' => 'textfield',
							'std' => '',
							'description' => __( 'Provide comma separated cuisines if not in above list. E.g. Rajasthani, Gujarati', 'trg' ),
							'group' => __( 'Recipe Meta', 'trg' )
						),

						array(
							'heading' => __( 'Recipe Category', 'trg' ),
							'type' => 'dropdown_multiple',
							'param_name' => 'recipe_category',
							'value' => apply_filters( 'trg_category_list', array(
									__( 'Appetizer', 'trg' ) => __( 'Appetizer', 'trg' ),
									__( 'Breakfast', 'trg' ) => __( 'Breakfast', 'trg' ),
									__( 'Dessert', 'trg' ) => __( 'Dessert', 'trg' ),
									__( 'Drinks', 'trg' ) => __( 'Drinks', 'trg' ),
									__( 'Main Course', 'trg' ) => __( 'Main Course', 'trg' ),
									__( 'Salad', 'trg' ) => __( 'Salad', 'trg' ),
									__( 'Snack', 'trg' ) => __( 'Snack', 'trg' ),
									__( 'Soup', 'trg' ) => __( 'Soup', 'trg' )
								)
							),
							'std' => '',
							'description' => __( 'Select recipe categories from above list or use custom field below', 'trg' ),
							'group' => __( 'Recipe Meta', 'trg' )
						),

						array(
							'heading' => __( 'Other recipe category', 'trg' ),
							'param_name' => 'recipe_category_other',
							'type' => 'textfield',
							'std' => '',
							'description' => __( 'Provide comma separated categories if not in above list. E.g. Lunch, Starter', 'trg' ),
							'group' => __( 'Recipe Meta', 'trg' )
						),

						array(
							'param_name' => 'show_tags',
							'heading' => __( 'Display tags/keywords', 'trg' ),
							'type' => 'checkbox',
							'value' => array( __( 'Display post tags/keywords in recipe meta', 'trg' ) => 'true' ),
							'description' => __( 'Enabling this option will show post tags with schema property "keywords" in recipe meta. You can add tags in the "Tags" panel of post edit screen.', 'trg' ),
							'group' => __( 'Recipe Meta', 'trg' )
						),

						array(
							'param_name' => 'tags_schema_only',
							'heading' => __( 'Hidden Tags/keywords as Schema', 'trg' ),
							'type' => 'checkbox',
							'value' => array( __( 'Include post tags/keywords as hidden schema', 'trg' ) => 'true' ),
							'description' => __( 'Enabling this option will use post tags/keywords as hidden schema instead of displaying them.', 'trg' ),
							'group' => __( 'Recipe Meta', 'trg' )
						),

						array(
							'heading' => __( 'Cooking Method', 'trg' ),
							'param_name' => 'cooking_method',
							'type' => 'textfield',
							'std' => '',
							'description' => __( 'Provide a cooking method. E.g. Roasting, Steaming', 'trg' ),
							'group' => __( 'Recipe Meta', 'trg' )
						),

						array(
							'heading' => __( 'Preparation Time (Minutes)', 'trg' ),
							'param_name' => 'prep_time',
							'type' => 'textfield_num',
							'value' => '1',
							'min' => '1',
							'max' => '99999',
							'std' => '5',
							'description' => __( 'Provide preparation time (in minutes). E.g. 10', 'trg' ),
							'group' => __( 'Recipe Meta', 'trg' )
						),

						array(
							'heading' => __( 'Cooking Time (Minutes)', 'trg' ),
							'param_name' => 'cook_time',
							'type' => 'textfield_num',
							'value' => '1',
							'min' => '1',
							'max' => '99999',
							'std' => '10',
							'description' => __( 'Provide cooking time (in minutes). E.g. 30', 'trg' ),
							'group' => __( 'Recipe Meta', 'trg' )

						),
						
						array(
							'heading' => __( 'Total Time (Minutes)', 'trg' ),
							'param_name' => 'total_time',
							'type' => 'textfield_num',
							'value' => '1',
							'min' => '1',
							'max' => '99999',
							'std' => '',
							'description' => __( 'Provide total recipe time (in minutes). E.g. 20. Leave blank for auto calculation from prep time and cook time.', 'trg' ),
							'group' => __( 'Recipe Meta', 'trg' )
						),
						
						array(
							'heading' => __( 'Total Cost', 'trg' ),
							'param_name' => 'total_cost',
							'type' => 'textfield',
							'std' => '',
							'description' => __( 'Provide total cost of recipe.', 'trg' ),
							'group' => __( 'Recipe Meta', 'trg' )
						),
						
						array(
							'heading' => __( 'Cost per serving', 'trg' ),
							'param_name' => 'cost_per_serving',
							'type' => 'textfield',
							'std' => '',
							'description' => __( 'Provide cost per serving.', 'trg' ),
							'group' => __( 'Recipe Meta', 'trg' )
						),

						array(
							'heading' => __( 'Recipe Author', 'trg' ),
							'type' => 'dropdown',
							'param_name' => 'author_src',
							'value' => array(
									__( 'Use Post Author', 'trg' ) => 'post_author',
									__( 'Custom Author Name', 'trg' ) => 'custom'
							),
							'std' => 'post_author',
							'description' => __( 'Select author name source for recipe', 'trg' ),
							'group' => __( 'Recipe Meta', 'trg' )
						),

						array(
							'heading' => __( 'Custom Author name', 'trg' ),
							'param_name' => 'author_name',
							'type' => 'textfield',
							'std' => '',
							'description' => __( 'Provide name of author', 'trg' ),
							'dependency' => array(
								'element'    => 'author_src',
								'value' => 'custom'
							),
							'group' => __( 'Recipe Meta', 'trg' )
						),

						array(
							'heading' => __( 'Author profile URL', 'trg' ),
							'param_name' => 'author_url',
							'type' => 'textfield',
							'std' => '',
							'description' => __( 'The profile URL of recipe Author. Leave blank to use WordPress user URL.', 'trg' ),
							'group' => __( 'Recipe Meta', 'trg' )
						),

						// Ingredients Tab
						array(
							'type' => 'textfield',
							'value' => '',
							'heading' => __( 'Ingredients Heading', 'trg' ),
							'param_name' => 'ing_heading',
							'description' => __( 'Provide a heading for ingredients section', 'trg' ),
							'group' => __( 'Ingredients', 'trg' )
						),

						array(
							'type' => 'param_group',
							'value' => urlencode( json_encode( array(
											array(
												'title' => __( 'For the burger', 'js_composer' ),
												'list' => "200g wheat floor\r\n1 tbsp vegetable oil\r\n2 tsp sugar\r\n3 cups water"
											)
										) ) ),
							'param_name' => 'ingredients',
							// Sub params of a group item
							'params' => array(
								array(
									'type' => 'textfield',
									'value' => '',
									'heading' => __( 'Ingredients group title', 'trg' ),
									'param_name' => 'title',
									'description' => __( 'Provide optional group title if you want to separate ingredients in groups.', 'trg' ),
									'admin_label' => true
								),

								array(
									'type' => 'textarea',
									'value' => '',
									'param_name' => 'list',
									'heading' => __( 'Ingredients list', 'trg' ),
									'description' => __( 'Enter ingredient items, each on new line.', 'trg' ),
								)
							),
							'group' => __( 'Ingredients', 'trg' )
						),

						// Nutrition tab

						array(
							'heading' => __( 'Nutrition facts label heading', 'trg' ),
							'param_name' => 'nutri_heading',
							'type' => 'textfield',
							'std' => __( 'Nutrition Facts', 'trg' ),
							'description' => __( 'Provide a heading for nutrition facts table.', 'trg' ),
							'group' => __( 'Nutrition', 'trg' )
						),
						
						array(
							'heading' => __( 'Nutrition table style', 'trg' ),
							'type' => 'dropdown',
							'param_name' => 'display_style',
							'value' => array(
									__( 'Classic', 'trg' )  => 'classic',
									__( 'Classic Tabular', 'trg' )  => 'classic tabular',							
									__( 'Standard', 'trg' )  => 'std',
									__( 'Flat', 'trg' )  => 'flat',
									__( 'Flat Striped', 'trg' )  => 'flat striped',
									__( 'Lined', 'trg' )  => 'lined'
							),
							'std' => 'classic',
							'description' => __( 'Select a style for Nutrition table.', 'trg' ),
							'group' => __( 'Nutrition', 'trg' )
						),
						
						array(
							'param_name' => 'show_dv',
							'heading' => __( 'Show standard Daily Values', 'trg' ),
							'type' => 'checkbox',
							'value' => array( __( 'Show standard Daily Values', 'trg' ) => 'true' ),
							'description' => __( 'Enabling this option will show standard Daily Values in the chart.', 'trg' ),
							'group' => __( 'Nutrition', 'trg' )
						),

						array(
							'heading' => __( 'Nutrition label extra notes', 'trg' ),
							'param_name' => 'extra_notes',
							'type' => 'textarea',
							'std' => __( '* The % Daily Value (DV) tells you how much a nutrient in a serving of food contributes to a daily diet. 2,000 calories a day is used for general nutrition advice.', 'trg' ),
							'description' => __( 'Provide extra notes for the Nutrition table. This will be displayed at the end of table.', 'trg' ),
							'group' => __( 'Nutrition', 'trg' )
						),												

						array(
							'heading' => __( 'Recipe Yield', 'trg' ),
							'param_name' => 'recipe_yield',
							'type' => 'textfield',
							'std' => '',
							'description' => __( 'Provide a recipe yield. E.g. 1 Pizza, or 1 Bowl Rice', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							'group' => __( 'Nutrition', 'trg' )
						),

						array(
							'heading' => __( 'Serving Size', 'trg' ),
							'param_name' => 'serving_size',
							'type' => 'textfield',
							'std' => '',
							'description' => __( 'Provide a serving size per container. E.g. 1 Piece(20g), or 100g', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							'group' => __( 'Nutrition', 'trg' )
						),
						
						array(
							'heading' => __( 'Serving Per Container', 'trg' ),
							'param_name' => 'serving_per_cont',
							'type' => 'textfield_num',
							'min'	=> '0',
							'std' => '',
							'description' => __( 'Provide serving per container. E.g. 30', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							'group' => __( 'Nutrition', 'trg' )
						),
						

						array(
							'heading' => __( 'Calorie per serving (cal)', 'trg' ),
							'param_name' => 'calories',
							'type' => 'textfield_num',
							'min'	=> '0',
							'std' => '',
							'description' => __( 'Provide approximate calories (without unit) per serving. E.g. 240', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column',							
							'group' => __( 'Nutrition', 'trg' )
						),												

						array(
							'heading' => __( 'Suitable for Diet', 'trg' ),
							'type' => 'dropdown_multiple',
							'param_name' => 'suitable_for_diet',
							'value' => apply_filters( 'trg_suitable_for_diet', array(
									__( 'Diabetic', 'trg' ) => 'Diabetic',
									__( 'Gluten Free', 'trg' ) => 'Gluten Free',
									__( 'Halal', 'trg' ) => 'Halal',
									__( 'Hindu', 'trg' ) => 'Hindu',
									__( 'Kosher', 'trg' ) => 'Kosher',
									__( 'Low Calorie', 'trg' ) => 'Low Calorie',
									__( 'Low Fat', 'trg' ) => 'Low Fat',
									__( 'Low Lactose', 'trg' ) => 'Low Lactose',
									__( 'Low Salt', 'trg' ) => 'Low Salt',
									__( 'Vegan', 'trg' ) => 'Vegan',
									__( 'Vegetarian', 'trg' ) => 'Vegetarian'
								)
							),
							'std' => '',
							'description' => __( 'Select diet for which this recipe is suitable. Remove selection using "ctrl + select" if not applicable.', 'trg' ),
							'group' => __( 'Nutrition', 'trg' )
						),
						
						array(
							'heading' => __( 'Other Suitable for Diet', 'trg' ),
							'param_name' => 'suitable_for_diet_other',
							'type' => 'textfield',
							'std' => '',
							'description' => __( 'Provide comma separated values for other suitable for diet. E.g. Organic, Jain', 'trg' ),
							'group' => __( 'Nutrition', 'trg' )
						),

						array(
							'heading' => __( 'Total Fat', 'trg' ),
							'param_name' => 'total_fat',
							'type' => 'textfield_num',
							'min'	=> '0',
							'std' => '',
							'description' => __( 'The amount of Total Fat (g), without unit. Standard daily value is 78 g', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							'group' => __( 'Nutrition', 'trg' )
						),

						array(
							'heading' => __( 'Saturated Fat', 'trg' ),
							'param_name' => 'saturated_fat',
							'type' => 'textfield_num',
							'min'	=> '0',
							'std' => '',
							'description' => __( 'The amount of Saturated Fat (g), without unit. Standard daily value is 20 g', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							'group' => __( 'Nutrition', 'trg' )
						),

						array(
							'heading' => __( 'Trans Fat', 'trg' ),
							'param_name' => 'trans_fat',
							'type' => 'textfield_num',
							'min'	=> '0',
							'std' => '',
							'description' => __( 'The amount of Trans Fat (g), without unit. ', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							'group' => __( 'Nutrition', 'trg' )
						),

						array(
							'heading' => __( 'Polyunsaturated Fat', 'trg' ),
							'param_name' => 'polyunsat_fat',
							'type' => 'textfield_num',
							'min'	=> '0',
							'std' => '',
							'description' => __( 'The amount of Polyunsaturated Fat (g), without unit. ', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							'group' => __( 'Nutrition', 'trg' )
						),

						array(
							'heading' => __( 'Monounsaturated Fat', 'trg' ),
							'param_name' => 'monounsat_fat',
							'type' => 'textfield_num',
							'min'	=> '0',
							'std' => '',
							'description' => __( 'The amount of Monounsaturated Fat (g), without unit. ', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							'group' => __( 'Nutrition', 'trg' )
						),

						array(
							'heading' => __( 'Cholesterol', 'trg' ),
							'param_name' => 'cholesterol',
							'type' => 'textfield_num',
							'min'	=> '0',
							'std' => '',
							'description' => __( 'The amount of Cholesterol (mg), without unit. Standard daily value is 300 mg', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							'group' => __( 'Nutrition', 'trg' )
						),

						array(
							'heading' => __( 'Sodium', 'trg' ),
							'param_name' => 'sodium',
							'type' => 'textfield_num',
							'min'	=> '0',
							'std' => '',
							'description' => __( 'The amount of Sodium (mg), without unit. Standard daily value is 2300 mg', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							'group' => __( 'Nutrition', 'trg' )
						),

						array(
							'heading' => __( 'Total Carbohydrate', 'trg' ),
							'param_name' => 'carbohydrate',
							'type' => 'textfield_num',
							'min'	=> '0',
							'std' => '',
							'description' => __( 'The amount of Total Carbohydrate (g), without unit. Standard daily value is 275 g', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							'group' => __( 'Nutrition', 'trg' )
						),

						array(
							'heading' => __( 'Dietary Fiber', 'trg' ),
							'param_name' => 'fiber',
							'type' => 'textfield_num',
							'min'	=> '0',
							'std' => '',
							'description' => __( 'The amount of Dietary Fiber (g), without unit. Standard daily value is 28 g', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							'group' => __( 'Nutrition', 'trg' )
						),

						array(
							'heading' => __( 'Total Sugars', 'trg' ),
							'param_name' => 'sugar',
							'type' => 'textfield_num',
							'min'	=> '0',
							'std' => '',
							'description' => __( 'The amount of Total Sugars (g), without unit. ', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							'group' => __( 'Nutrition', 'trg' )
						),

						array(
							'heading' => __( 'Added Sugars', 'trg' ),
							'param_name' => 'added_sugar',
							'type' => 'textfield_num',
							'min'	=> '0',
							'std' => '',
							'description' => __( 'The amount of Added Sugars (g), without unit. Standard daily value is 50 g', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							'group' => __( 'Nutrition', 'trg' )
						),

						array(
							'heading' => __( 'Sugar Alcohal', 'trg' ),
							'param_name' => 'sugar_alcohal',
							'type' => 'textfield_num',
							'min'	=> '0',
							'std' => '',
							'description' => __( 'The amount of Sugar Alcohal (g), without unit. ', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							'group' => __( 'Nutrition', 'trg' )
						),

						array(
							'heading' => __( 'Protein', 'trg' ),
							'param_name' => 'protein',
							'type' => 'textfield_num',
							'min'	=> '0',
							'std' => '',
							'description' => __( 'The amount of Protein (g), without unit. Standard daily value is 50 g', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							'group' => __( 'Nutrition', 'trg' )
						),

						array(
							'heading' => __( 'Vitamin D (Cholecalciferol)', 'trg' ),
							'param_name' => 'vitamin_d',
							'type' => 'textfield_num',
							'min'	=> '0',
							'std' => '',
							'description' => __( 'The amount of Vitamin D (Cholecalciferol) (IU), without unit. Standard daily value is 800 IU (International Units) or 20 mcg', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							'group' => __( 'Nutrition', 'trg' )
						),

						array(
							'heading' => __( 'Calcium', 'trg' ),
							'param_name' => 'calcium',
							'type' => 'textfield_num',
							'min'	=> '0',
							'std' => '',
							'description' => __( 'The amount of Calcium (mg), without unit. Standard daily value is 1300 mg', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							'group' => __( 'Nutrition', 'trg' )
						),

						array(
							'heading' => __( 'Iron', 'trg' ),
							'param_name' => 'iron',
							'type' => 'textfield_num',
							'min'	=> '0',
							'std' => '',
							'description' => __( 'The amount of Iron (mg), without unit. Standard daily value is 18 mg', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							'group' => __( 'Nutrition', 'trg' )
						),

						array(
							'heading' => __( 'Potassium', 'trg' ),
							'param_name' => 'potassium',
							'type' => 'textfield_num',
							'min'	=> '0',
							'std' => '',
							'description' => __( 'The amount of Potassium (mg), without unit. Standard daily value is 4700 mg', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							'group' => __( 'Nutrition', 'trg' )
						),

						array(
							'heading' => __( 'Vitamin A', 'trg' ),
							'param_name' => 'vitamin_a',
							'type' => 'textfield_num',
							'min'	=> '0',
							'std' => '',
							'description' => __( 'The amount of Vitamin A (International Units), without unit. Standard daily value is 900 mcg', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							'group' => __( 'Nutrition', 'trg' )
						),

						array(
							'heading' => __( 'Vitamin C (Ascorbic Acid)', 'trg' ),
							'param_name' => 'vitamin_c',
							'type' => 'textfield_num',
							'min'	=> '0',
							'std' => '',
							'description' => __( 'The amount of Vitamin C (Ascorbic Acid) (mg), without unit. Standard daily value is 90 mg', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							'group' => __( 'Nutrition', 'trg' )
						),

						array(
							'heading' => __( 'Vitamin E (Tocopherol)', 'trg' ),
							'param_name' => 'vitamin_e',
							'type' => 'textfield_num',
							'min'	=> '0',
							'std' => '',
							'description' => __( 'The amount of Vitamin E (Tocopherol) (IU), without unit. Standard daily value is 33 IU or 15 mg', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							'group' => __( 'Nutrition', 'trg' )
						),

						array(
							'heading' => __( 'Vitamin K', 'trg' ),
							'param_name' => 'vitamin_k',
							'type' => 'textfield_num',
							'min'	=> '0',
							'std' => '',
							'description' => __( 'The amount of Vitamin K (mcg), without unit. Standard daily value is 120 mcg', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							'group' => __( 'Nutrition', 'trg' )
						),

						array(
							'heading' => __( 'Vitamin B1 (Thiamin)', 'trg' ),
							'param_name' => 'vitamin_b1',
							'type' => 'textfield_num',
							'min'	=> '0',
							'std' => '',
							'description' => __( 'The amount of Vitamin B1 (Thiamin) (mg), without unit. Standard daily value is 1.2 mg', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							'group' => __( 'Nutrition', 'trg' )
						),

						array(
							'heading' => __( 'Vitamin B2 (Riboflavin)', 'trg' ),
							'param_name' => 'vitamin_b2',
							'type' => 'textfield_num',
							'min'	=> '0',
							'std' => '',
							'description' => __( 'The amount of Vitamin B2 (Riboflavin) (mg), without unit. Standard daily value is 1.3 mg', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							'group' => __( 'Nutrition', 'trg' )
						),

						array(
							'heading' => __( 'Vitamin B3 (Niacin)', 'trg' ),
							'param_name' => 'vitamin_b3',
							'type' => 'textfield_num',
							'min'	=> '0',
							'std' => '',
							'description' => __( 'The amount of Vitamin B3 (Niacin) (mg), without unit. Standard daily value is 16 mg', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							'group' => __( 'Nutrition', 'trg' )
						),

						array(
							'heading' => __( 'Vitamin B6 (Pyridoxine)', 'trg' ),
							'param_name' => 'vitamin_b6',
							'type' => 'textfield_num',
							'min'	=> '0',
							'std' => '',
							'description' => __( 'The amount of Vitamin B6 (Pyridoxine) (mg), without unit. Standard daily value is 1.7 mg', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							'group' => __( 'Nutrition', 'trg' )
						),

						array(
							'heading' => __( 'Folate', 'trg' ),
							'param_name' => 'folate',
							'type' => 'textfield_num',
							'min'	=> '0',
							'std' => '',
							'description' => __( 'The amount of Folate (mcg), without unit. Standard daily value is 400 mcg', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							'group' => __( 'Nutrition', 'trg' )
						),

						array(
							'heading' => __( 'Vitamin B12 (Cobalamine)', 'trg' ),
							'param_name' => 'vitamin_b12',
							'type' => 'textfield_num',
							'min'	=> '0',
							'std' => '',
							'description' => __( 'The amount of Vitamin B12 (Cobalamine) (mcg), without unit. Standard daily value is 2.4 mcg', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							'group' => __( 'Nutrition', 'trg' )
						),

						array(
							'heading' => __( 'Biotin', 'trg' ),
							'param_name' => 'biotin',
							'type' => 'textfield_num',
							'min'	=> '0',
							'std' => '',
							'description' => __( 'The amount of Biotin (mcg), without unit. Standard daily value is 30 mcg', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							'group' => __( 'Nutrition', 'trg' )
						),

						array(
							'heading' => __( 'Choline', 'trg' ),
							'param_name' => 'choline',
							'type' => 'textfield_num',
							'min'	=> '0',
							'std' => '',
							'description' => __( 'The amount of Choline (mg), without unit. Standard daily value is 550 mg', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							'group' => __( 'Nutrition', 'trg' )
						),

						array(
							'heading' => __( 'Vitamin B5 (Pantothenic acid)', 'trg' ),
							'param_name' => 'vitamin_b5',
							'type' => 'textfield_num',
							'min'	=> '0',
							'std' => '',
							'description' => __( 'The amount of Vitamin B5 (Pantothenic acid) (mg), without unit. Standard daily value is 5 mg', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							'group' => __( 'Nutrition', 'trg' )
						),

						array(
							'heading' => __( 'Phosphorus', 'trg' ),
							'param_name' => 'phosphorus',
							'type' => 'textfield_num',
							'min'	=> '0',
							'std' => '',
							'description' => __( 'The amount of Phosphorus (mg), without unit. Standard daily value is 1250 mg', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							'group' => __( 'Nutrition', 'trg' )
						),

						array(
							'heading' => __( 'Iodine', 'trg' ),
							'param_name' => 'iodine',
							'type' => 'textfield_num',
							'min'	=> '0',
							'std' => '',
							'description' => __( 'The amount of Iodine (mcg), without unit. Standard daily value is 150 mcg', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							'group' => __( 'Nutrition', 'trg' )
						),

						array(
							'heading' => __( 'Magnesium', 'trg' ),
							'param_name' => 'magnesium',
							'type' => 'textfield_num',
							'min'	=> '0',
							'std' => '',
							'description' => __( 'The amount of Magnesium (mg), without unit. Standard daily value is 420 mg', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							'group' => __( 'Nutrition', 'trg' )
						),

						array(
							'heading' => __( 'Zinc', 'trg' ),
							'param_name' => 'zinc',
							'type' => 'textfield_num',
							'min'	=> '0',
							'std' => '',
							'description' => __( 'The amount of Zinc (mg), without unit. Standard daily value is 11 mg', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							'group' => __( 'Nutrition', 'trg' )
						),

						array(
							'heading' => __( 'Selenium', 'trg' ),
							'param_name' => 'selenium',
							'type' => 'textfield_num',
							'min'	=> '0',
							'std' => '',
							'description' => __( 'The amount of Selenium (mcg), without unit. Standard daily value is 55 mcg', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							'group' => __( 'Nutrition', 'trg' )
						),

						array(
							'heading' => __( 'Copper', 'trg' ),
							'param_name' => 'copper',
							'type' => 'textfield_num',
							'min'	=> '0',
							'std' => '',
							'description' => __( 'The amount of Copper (mg), without unit. Standard daily value is .9 mg', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							'group' => __( 'Nutrition', 'trg' )
						),

						array(
							'heading' => __( 'Manganese', 'trg' ),
							'param_name' => 'manganese',
							'type' => 'textfield_num',
							'min'	=> '0',
							'std' => '',
							'description' => __( 'The amount of Manganese (mg), without unit. Standard daily value is 2.3 mg', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							'group' => __( 'Nutrition', 'trg' )
						),

						array(
							'heading' => __( 'Chromium', 'trg' ),
							'param_name' => 'chromium',
							'type' => 'textfield_num',
							'min'	=> '0',
							'std' => '',
							'description' => __( 'The amount of Chromium (mcg), without unit. Standard daily value is 35 mcg', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							'group' => __( 'Nutrition', 'trg' )
						),

						array(
							'heading' => __( 'Molybdenum', 'trg' ),
							'param_name' => 'molybdenum',
							'type' => 'textfield_num',
							'min'	=> '0',
							'std' => '',
							'description' => __( 'The amount of Molybdenum (mcg), without unit. Standard daily value is 45 mcg', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							'group' => __( 'Nutrition', 'trg' )
						),

						array(
							'heading' => __( 'Chloride', 'trg' ),
							'param_name' => 'chloride',
							'type' => 'textfield_num',
							'min'	=> '0',
							'std' => '',
							'description' => __( 'The amount of Chloride (mg), without unit. Standard daily value is 2300 mg', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							'group' => __( 'Nutrition', 'trg' )
						),
						
						// Custom Nutrients
						array(
							'type' => 'param_group',
							'value' => urlencode(
										json_encode(
											array(
												array(
													'name' => '',
													'unit' => '',
													'amt' => '',
													'sv' => '',
													'level' => '',
													'text_style' => ''
												)
											)
										)
									),
							'param_name' => 'custom_nutrients',
							// Sub params of a group item
							'params' => array(
								array(
									'type' => 'textfield',
									'value' => '',
									'heading' => __( 'Nutrient name', 'trg' ),
									'param_name' => 'name',
									'description' => __( 'Provide a nutrient name. E.g. Power Protein', 'trg' ),
									'admin_label' => true
								),
								
								array(
									'type' => 'textfield',
									'value' => '',
									'heading' => __( 'Nutrient Quantity Unit', 'trg' ),
									'param_name' => 'unit',
									'description' => __( 'Provide a nutrient unit. E.g. mg', 'trg' )
								),
								
								array(
									'type' => 'textfield',
									'value' => '',
									'heading' => __( 'Amount per serving', 'trg' ),
									'param_name' => 'amt',
									'description' => __( 'Provide amount per serving (without unit). E.g. 20', 'trg' )
								),
								
								array(
									'type' => 'textfield',
									'value' => '',
									'heading' => __( 'Standard daily value', 'trg' ),
									'param_name' => 'sv',
									'description' => __( 'Provide standard daily value of Nutrient (without unit). E.g. 200', 'trg' )
								),
								
								array(
									'heading' => __( 'Nutrient indent level', 'trg' ),
									'type' => 'dropdown',
									'param_name' => 'level',
									'value' => array(
										__( 'Level 0', 'trg' ) => '0',
										__( 'Level 1', 'trg' ) => '1',
										__( 'Level 2', 'trg' ) => '2',
										__( 'Level 3', 'trg' ) => '3'
									),
									'std' => '',
									'description' => __( 'Select indent level for Nutrient entry in table.', 'trg' )
								),
								
								array(
									'heading' => __( 'Nutrient text style', 'trg' ),
									'type' => 'dropdown',
									'param_name' => 'text_style',
									'value' => array(
										__( 'Normal', 'trg' ) => 'normal',
										__( 'Bold', 'trg' ) => 'bold'
									),
									'std' => '',
									'description' => __( 'Select text style for the nutrient entry.', 'trg' )
								),
							),
							'group' => __( 'Add Nutrients', 'trg' )
						),						

						// Hide meta tab
						array(
							'param_name'  => 'json_ld',
							'label'       => __( 'Enable JSON LD microdata', 'trg' ),
							'type'        => 'checkbox',
							'description' => __( 'Enabling this option will add json ld schema data in recipe container.', 'trg' ),
							'value' => array( __( 'Enable JSON LD microdata', 'trg' ) => 'true' ),
							'std'		  => 'true',
							'group' => __( 'Misc', 'trg' )
						),

						array(
							'param_name'        => 'enable_numbering',
							'label'       => 'Enable numbering',
							'type'        => 'checkbox',
							'description' => __( 'Check to enable auto numbering on method steps', 'trg' ),
							'value' => array( __( 'Enable auto numbering on method steps', 'trg' ) => 'true' ),
							'std'		  => 'true',
							'group' => __( 'Misc', 'trg' )
						),

						array(
							'param_name' => 'hide_name',
							'heading' => __( 'Recipe name', 'trg' ),
							'type'        => 'checkbox',
							'description' => __( 'If checked, recipe name will not be displayed. It will be used for schema only', 'trg' ),
							'value' => array( __( 'Hide recipe name', 'trg' ) => 'true' ),
							'group' => __( 'Misc', 'trg' )
						),

						array(
							'param_name' => 'hide_date',
							'heading' => __( 'Publish date', 'trg' ),
							'type'        => 'checkbox',
							'description' => __( 'If checked, publish date will not be displayed. It will be used for schema only', 'trg' ),
							'value' => array( __( 'Hide recipe publish date', 'trg' ) => 'true' ),
							'group' => __( 'Misc', 'trg' )
						),

						array(
							'param_name' => 'hide_author',
							'heading' => __( 'Recipe Author', 'trg' ),
							'type'        => 'checkbox',
							'description' => __( 'If checked, author name will not be displayed. It will be used for schema only', 'trg' ),
							'value' => array( __( 'Hide author name', 'trg' ) => 'true' ),
							'group' => __( 'Misc', 'trg' )
						),

						array(
							'param_name' => 'hide_img',
							'heading' => __( 'Recipe image', 'trg' ),
							'type'        => 'checkbox',
							'description' => __( 'If checked, recipe image will not be displayed. It will be used for schema only', 'trg' ),
							'value' => array( __( 'Hide recipe image', 'trg' ) => 'true' ),
							'group' => __( 'Misc', 'trg' )
						),

						array(
							'param_name' => 'hide_summary',
							'heading' => __( 'Recipe summary', 'trg' ),
							'type'        => 'checkbox',
							'description' => __( 'If checked, recipe summary will not be displayed. It will be used for schema only.', 'trg' ),
							'value' => array( __( 'Hide recipe summary', 'trg' ) => 'true' ),
							'group' => __( 'Misc', 'trg' )
						),

						array(
							'param_name' => 'hide_nutrition',
							'heading' => __( 'Nutrition Facts', 'trg' ),
							'type'        => 'checkbox',
							'description' => __( 'If checked, nutrition facts section will not be displayed.', 'trg' ),
							'value' => array( __( 'Hide nutrition facts', 'trg' ) => 'true' ),
							'group' => __( 'Misc', 'trg' )
						),

						array(
							'heading' => __( 'Social sharing heading', 'trg' ),
							'param_name' => 'social_heading',
							'type' => 'textfield',
							'std' => '',
							'description' => __( 'Provide a heading for social sharing buttons', 'trg' ),
							'group' => __( 'Social', 'trg' )
						),

						array(
							'heading' => __( 'Social Sharing buttons', 'trg' ),
							'type' => 'dropdown_multiple',
							'param_name' => 'social_buttons',
							'value' => array(
								__( 'Twitter', 'trg' ) => 'twitter',
								__( 'Facebook', 'trg' ) => 'facebook',
								__( 'WhatsApp', 'trg' ) => 'whatsapp',
								__( 'Google Plus', 'trg' ) => 'googleplus',
								__( 'LinkedIn', 'trg' ) => 'linkedin',
								__( 'Pinterest', 'trg' ) => 'pinterest',
								__( 'VKOntakte', 'trg' ) => 'vkontakte',
								__( 'Email', 'trg' ) => 'email',
								__( 'Print', 'trg' ) => 'print',
								__( 'Reddit', 'trg' ) => 'reddit',
							),
							'std' => '',
							'description' => __( 'Select social share buttons to show at the end of recipe', 'trg' ),
							'group' => __( 'Social', 'trg' )
						),
						array(
							'param_name' => 'social_sticky',
							'heading' => __( 'Sticky Social Buttons', 'trg' ),
							'type'        => 'checkbox',
							'description' => __( 'If checked, social buttons will become sticky (fix positioned) on mobile', 'trg' ),
							'value' => array( __( 'Make social buttons sticky on mobile', 'trg' ) => 'true' ),
							'group' => __( 'Social', 'trg' )
						),
						
						array(
							'type' => 'colorpicker',
							'class' => '',
							'heading' => __( 'Icons color', 'trg' ),
							'param_name' => 'icon_color',
							'value' => '',
							'description' => __( 'Choose a color for heading icons', 'trg' ),
							'group' => __( 'Colors', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column'
						),
						
						array(
							'type' => 'colorpicker',
							'class' => '',
							'heading' => __( 'Headings color', 'trg' ),
							'param_name' => 'heading_color',
							'value' => '',
							'description' => __( 'Choose a color for headings', 'trg' ),
							'group' => __( 'Colors', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column'
						),
						
						array(
							'type' => 'colorpicker',
							'class' => '',
							'heading' => __( 'Tag links background', 'trg' ),
							'param_name' => 'tags_bg',
							'value' => '',
							'description' => __( 'Choose a background color for tag links', 'trg' ),
							'group' => __( 'Colors', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column'
						),
						
						array(
							'type' => 'colorpicker',
							'class' => '',
							'heading' => __( 'Tag links color', 'trg' ),
							'param_name' => 'tags_color',
							'value' => '',
							'description' => __( 'Choose a color for tag links', 'trg' ),
							'group' => __( 'Colors', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column'
						),
						
						array(
							'type' => 'colorpicker',
							'class' => '',
							'heading' => __( 'Tag links background hover color', 'trg' ),
							'param_name' => 'tags_bg_hover',
							'value' => '',
							'description' => __( 'Choose a hover background color for tag links', 'trg' ),
							'group' => __( 'Colors', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column'
						),
						
						array(
							'type' => 'colorpicker',
							'class' => '',
							'heading' => __( 'Tag links hover color', 'trg' ),
							'param_name' => 'tags_color_hover',
							'value' => '',
							'description' => __( 'Choose a hover color for tag links', 'trg' ),
							'group' => __( 'Colors', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column'
						),
						
						array(
							'type' => 'colorpicker',
							'class' => '',
							'heading' => __( 'Text labels color', 'trg' ),
							'param_name' => 'label_color',
							'value' => '',
							'description' => __( 'Choose a color for text labels in recipe meta', 'trg' ),
							'group' => __( 'Colors', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column'
						),
						
						array(
							'type' => 'colorpicker',
							'class' => '',
							'heading' => __( 'Text highlights color', 'trg' ),
							'param_name' => 'highlights',
							'value' => '',
							'description' => __( 'Choose a highlight color for text in recipe meta', 'trg' ),
							'group' => __( 'Colors', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column'
						),
						
						array(
							'type' => 'colorpicker',
							'class' => '',
							'heading' => __( 'Color for number count', 'trg' ),
							'param_name' => 'count_color',
							'value' => '',
							'description' => __( 'Choose a color for number count in recipe method', 'trg' ),
							'group' => __( 'Colors', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column'
						),
						
						array(
							'type' => 'colorpicker',
							'class' => '',
							'heading' => __( 'Ingredients tick color', 'trg' ),
							'param_name' => 'tick_color',
							'value' => '',
							'description' => __( 'Choose a color for tick icon in ingredients section', 'trg' ),
							'group' => __( 'Colors', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column'
						)
					),
				'js_view' => 'VcColumnView'
				)
			); // [trg_recipe]

			// [trg_recipe_method]
			vc_map( array(
					'name' => __( 'Recipe Method', 'trg' ),
					'base' => 'trg_recipe_method',
					'icon' =>  plugin_dir_url( __FILE__ ) . 'assets/images/trg_method.svg',
					'description' => __( 'Creates recipe method', 'trg' ),
					'content_element' => true,
					'is_container' => true,
					'show_settings_on_create' => false,
					'as_parent' => array(
						'except' => 'trg_recipe',
					),
					'as_child' => array('only' => 'trg_recipe'),
					'show_settings_on_create' => true,
					'params' => array(
						array(
							'type' => 'textfield',
							'heading' => __( 'Method Group Title', 'trg' ),
							'param_name' => 'method_title',
							'description' => __( 'Provide a title if you wish to separate instructions method in group. You can use text block or other elements to show in Recipe Method.', 'trg' ),
							'group' => __( 'General', 'trg' )
						)
					),
					'js_view' => 'VcColumnView'
				)
			); // [trg_recipe_method]
			
			vc_map( array(
					'name' => __( 'TRG Title', 'trg' ),
					'base' => 'trg_title',
					'icon' =>  plugin_dir_url( __FILE__ ) . 'assets/images/trg_title.svg',
					'description' => __( 'Title text with icons', 'trg' ),
					'params' => array(
						array(
							'type' => 'dropdown',
							'heading' => __( 'Icon library', 'js_composer' ),
							'value' => array(
								__( 'Font Awesome', 'js_composer' ) => 'fontawesome',
								__( 'Open Iconic', 'js_composer' ) => 'openiconic',
								__( 'Typicons', 'js_composer' ) => 'typicons',
								__( 'Entypo', 'js_composer' ) => 'entypo',
								__( 'Linecons', 'js_composer' ) => 'linecons',
								__( 'Mono Social', 'js_composer' ) => 'monosocial',
								__( 'Material', 'js_composer' ) => 'material',
							),
							'std' => 'fontawesome',
							'group' => __( 'General', 'trg' ),
							'admin_label' => true,
							'param_name' => 'type',
							'description' => __( 'Select icon library.', 'js_composer' ),
						),
						array(
							'type' => 'iconpicker',
							'heading' => __( 'Icon', 'js_composer' ),
							'param_name' => 'icon_fontawesome',
							'value' => 'fa fa-adjust',
							// default value to backend editor admin_label
							'settings' => array(
								'emptyIcon' => false,
								// default true, display an "EMPTY" icon?
								'iconsPerPage' => 4000,
								// default 100, how many icons per/page to display, we use (big number) to display all icons in single page
							),
							'dependency' => array(
								'element' => 'type',
								'value' => 'fontawesome',
							),
							'group' => __( 'General', 'trg' ),
							'description' => __( 'Select icon from library.', 'js_composer' ),
						),
						array(
							'type' => 'iconpicker',
							'heading' => __( 'Icon', 'js_composer' ),
							'param_name' => 'icon_openiconic',
							'value' => 'vc-oi vc-oi-dial',
							// default value to backend editor admin_label
							'settings' => array(
								'emptyIcon' => false,
								// default true, display an "EMPTY" icon?
								'type' => 'openiconic',
								'iconsPerPage' => 4000,
								// default 100, how many icons per/page to display
							),
							'group' => __( 'General', 'trg' ),
							'dependency' => array(
								'element' => 'type',
								'value' => 'openiconic',
							),
							'description' => __( 'Select icon from library.', 'js_composer' ),
						),
						array(
							'type' => 'iconpicker',
							'heading' => __( 'Icon', 'js_composer' ),
							'param_name' => 'icon_typicons',
							'value' => 'typcn typcn-adjust-brightness',
							// default value to backend editor admin_label
							'settings' => array(
								'emptyIcon' => false,
								// default true, display an "EMPTY" icon?
								'type' => 'typicons',
								'iconsPerPage' => 4000,
								// default 100, how many icons per/page to display
							),
							'group' => __( 'General', 'trg' ),
							'dependency' => array(
								'element' => 'type',
								'value' => 'typicons',
							),
							'description' => __( 'Select icon from library.', 'js_composer' ),
						),
						array(
							'type' => 'iconpicker',
							'heading' => __( 'Icon', 'js_composer' ),
							'param_name' => 'icon_entypo',
							'value' => 'entypo-icon entypo-icon-note',
							// default value to backend editor admin_label
							'settings' => array(
								'emptyIcon' => false,
								// default true, display an "EMPTY" icon?
								'type' => 'entypo',
								'iconsPerPage' => 4000,
								// default 100, how many icons per/page to display
							),
							'group' => __( 'General', 'trg' ),
							'dependency' => array(
								'element' => 'type',
								'value' => 'entypo',
							),
						),
						array(
							'type' => 'iconpicker',
							'heading' => __( 'Icon', 'js_composer' ),
							'param_name' => 'icon_linecons',
							'value' => 'vc_li vc_li-heart',
							// default value to backend editor admin_label
							'settings' => array(
								'emptyIcon' => false,
								// default true, display an "EMPTY" icon?
								'type' => 'linecons',
								'iconsPerPage' => 4000,
								// default 100, how many icons per/page to display
							),
							'group' => __( 'General', 'trg' ),
							'dependency' => array(
								'element' => 'type',
								'value' => 'linecons',
							),
							'description' => __( 'Select icon from library.', 'js_composer' ),
						),
						array(
							'type' => 'iconpicker',
							'heading' => __( 'Icon', 'js_composer' ),
							'param_name' => 'icon_monosocial',
							'value' => 'vc-mono vc-mono-fivehundredpx',
							// default value to backend editor admin_label
							'settings' => array(
								'emptyIcon' => false,
								// default true, display an "EMPTY" icon?
								'type' => 'monosocial',
								'iconsPerPage' => 4000,
								// default 100, how many icons per/page to display
							),
							'group' => __( 'General', 'trg' ),
							'dependency' => array(
								'element' => 'type',
								'value' => 'monosocial',
							),
							'description' => __( 'Select icon from library.', 'js_composer' ),
						),
						array(
							'type' => 'iconpicker',
							'heading' => __( 'Icon', 'js_composer' ),
							'param_name' => 'icon_material',
							'value' => 'vc-material vc-material-cake',
							// default value to backend editor admin_label
							'settings' => array(
								'emptyIcon' => false,
								// default true, display an "EMPTY" icon?
								'type' => 'material',
								'iconsPerPage' => 4000,
								// default 100, how many icons per/page to display
							),
							'group' => __( 'General', 'trg' ),
							'dependency' => array(
								'element' => 'type',
								'value' => 'material',
							),
							'description' => __( 'Select icon from library.', 'js_composer' ),
						),
						
						array(
							'type' => 'textfield',
							'heading' => __( 'Title Text', 'trg' ),
							'param_name' => 'text',
							'description' => __( 'Provide title text', 'trg' ),
							'group' => __( 'General', 'trg' )
						),
						
						array(
							'type' => 'dropdown',
							'heading' => __( 'Title Tag', 'trg' ),
							'param_name' => 'htag',
							'value' => array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p', 'span', 'div' ),
							'std' => 'h2',
							'description' => __( 'Select a tag for title container', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							'group' => __( 'General', 'trg' )
						),						

						array(
							'type' => 'textfield',
							'heading' => __( 'Link URL', 'trg' ),
							'param_name' => 'link',
							'description' => __( 'Provide a link URL for the text', 'trg' ),
							'group' => __( 'General', 'trg' )
						),

						array(
							'type' => 'textfield',
							'heading' => __( 'Link title attribute', 'trg' ),
							'param_name' => 'link_title',
							'description' => __( 'Provide a title attribute for the link', 'trg' ),
							'group' => __( 'General', 'trg' )
						),

						array(
							'type' => 'checkbox',
							'heading' => '',
							'param_name' => 'target',
							'description' => '',
							'value' => array( __( 'Open link in new tab', 'trg' ) => 'true' ),
							'group' => __( 'General', 'trg' )
						),

						array(
							'type' => 'colorpicker',
							'class' => '',
							'heading' => __( 'Icon Color', 'trg' ),
							'param_name' => 'icon_color',
							'value' => '',
							'description' => __( 'Choose icon color', 'trg' ),
							'group' => __( 'General', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column'
						),
						
						array(
							'type' => 'colorpicker',
							'class' => '',
							'heading' => __( 'Title Color', 'trg' ),
							'param_name' => 'title_color',
							'value' => '',
							'description' => __( 'Choose title text color', 'trg' ),
							'group' => __( 'General', 'trg' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column'
						),

						array(
							'type' => 'textfield',
							'heading' => __( 'Extra CSS class', 'trg' ),
							'param_name' => 'xclass',
							'description' => __( 'Any extra class you wish to add to the heading container', 'trg' ),
							'group' => __( 'General', 'trg' )
						)
					)
				) // trg_title
			);	// vc_map
		}


		// The [trg_recipe] shortcode function
		function trg_recipe( $atts, $content = null ) {
			extract( shortcode_atts( array(
				'template'			=> 'recipe',
				// Image specific
				'img_src'			=> 'featured', //media_lib, ext
				'img_lib'			=> '',
				'img_ext'			=> '',
				'img_alt'			=> '',
				'img_caption'		=> '',
				'imgwidth'			=> '',
				'imgheight'			=> '',
				'imgcrop'			=> '',
				'imgquality'		=> '',
				'img_align'			=> 'none',
				'hide_img'			=> false,
				'json_ld'			=> 'true', // Whether to include JSON LD microdata

				// Recipe name and summary
				'name_src'			=> 'post_title', // custom
				'name_txt'			=> '',
				'hide_name'			=> false,
				'summary'			=> '',
				'hide_summary'		=> false,
				'author_src'		=> 'post_author',
				'author_name'		=> '',
				'author_url'		=> '',
				'hide_author'		=> false,
				'hide_date'			=> false,
				'show_tags'			=> false,
				'tags_schema_only'	=> false,

				// Recipe meta
				'prep_time'			=> '5', // in minutes
				'cook_time'			=> '10', // in minutes
				'total_time'		=> '',
				'cooking_method'	=> '',
				'recipe_category'	=> '',
				'recipe_category_other'	=> '',
				'recipe_cuisine'	=> '',
				'recipe_cuisine_other'	=> '',
				'ingredients'		=> '', // Textarea data each on new line
				'ing_heading'		=> __( 'Ingredients', 'trg' ),
				'total_cost'		=> '',
				'cost_per_serving'	=> '',
				'method_heading'		=> __( 'Method', 'trg' ),
				'enable_numbering'  => 'true',
				'other_notes'		=> '',
				'social_buttons'	=> '',
				'social_heading'	=> '',
				'social_sticky'		=> false,
				'custom_nutrients'	=> '',

				// Nutrition facts
				'recipe_yield'		=> '',
				'suitable_for_diet'	=> '',
				'suitable_for_diet_other'	=> '',
				'hide_nutrition'  	=> false,
				'display_style'		=> 'classic',
				'serving_per_cont'	=> '',
				'serving_size'		=> '',
				'calories'			=> '',
				'nutri_heading'		=> __( 'Nutrition Facts', 'trg' ),
				'extra_notes'		=> __( '*Percent Daily Values are based on a 2,000 calorie diet. Your daily values may be higher or lower depending on your calorie needs.', 'trg' ),
				'show_dv'			=> false,

				// Nutrients
				'total_fat'			=> '',
				'saturated_fat'		=> '',
				'trans_fat'			=> '',
				'polyunsat_fat'		=> '',
				'monounsat_fat'		=> '',
				'cholesterol'		=> '',
				'sodium'			=> '',
				'carbohydrate'		=> '',
				'fiber'				=> '',
				'sugar'				=> '',
				'added_sugar'		=> '',
				'sugar_alcohal'		=> '',
				'protein'			=> '',
				'vitamin_d'			=> '',
				'calcium'			=> '',
				'iron'				=> '',
				'potassium'			=> '',
				'vitamin_a'			=> '',
				'vitamin_c'			=> '',
				'vitamin_e'			=> '',
				'vitamin_k'			=> '',
				'vitamin_b1'		=> '',
				'vitamin_b2'		=> '',
				'vitamin_b3'		=> '',
				'vitamin_b6'		=> '',
				'folate'			=> '',
				'vitamin_b12'		=> '',
				'biotin'			=> '',
				'choline'			=> '',
				'vitamin_b5'		=> '',
				'phosphorus'		=> '',
				'iodine'			=> '',
				'magnesium'			=> '',
				'zinc'				=> '',
				'selenium'			=> '',
				'copper'			=> '',
				'manganese'			=> '',
				'chromium'			=> '',
				'molybdenum'		=> '',
				'chloride'			=> '',
				
				// Misc
				'ad_spot_1'			=> '',
				'ad_spot_2'			=> '',
				'ad_spot_3'			=> '',
				
				// Colors
				'icon_color' 		=> '',
				'heading_color'		=> '',
				'tags_bg' 			=> '',
				'tags_color' 		=> '',
				'tags_bg_hover' 	=> '',
				'tags_color_hover' 	=> '',
				'label_color' 		=> '',
				'highlights' 		=> '',
				'count_color' 		=> '',
				'tick_color' 		=> ''
			), $atts ) );
			
			// Static vars for custom CSS class
			static $trg_css_count = 0;
			$trg_css_count++;
			$has_custom_css = false;
			$css_props = array (
				'icon_color',
				'heading_color',
				'tags_bg',
				'tags_color',
				'tags_bg_hover',
				'tags_color_hover',
				'label_color',
				'highlights',
				'count_color',
				'tick_color'
			);
			
			foreach( $css_props as $prop ) {
				if ( '' != $prop ) {
					$has_custom_css = true;
				}
			}

			// Merge Global settings
			$ad_spots = get_option( 'trg_adspots' );
			$social = get_option( 'trg_social' );
			$labels = get_option( 'trg_labels' );

			ob_start();

			$template_path = apply_filters( 'trg_template_path', '/trg_templates/' );

			if ( locate_template( $template_path . $template . '.php' ) ) {
				require( get_stylesheet_directory() . $template_path . $template . '.php' );
			}
			else {
				require( dirname( __FILE__ ) . $template_path . $template . '.php' );
			}

			$out = ob_get_contents();

			ob_end_clean();

			return $out;

		}

		// The [trg_recipe] shortcode function
		function trg_recipe_method( $atts, $content = null ) {
			extract( shortcode_atts( array(
				'method_title' => '',
				'xclass' => false,
			), $atts ) );

			$out = '';
			$num_box = '<span class="step-num step-%1$s">%1$s</span>';

			if ( isset( $GLOBALS['trg_recipe_step_count'] ) ) {
				$GLOBALS['trg_recipe_step_count']++;
			}
			else {
				$GLOBALS['trg_recipe_step_count'] = 1;
			}

			if ( '' !== $method_title ) {
				$out .= '<p class="inst-subhead">' . esc_attr( $method_title ) . '</p>';
			}

			$out .= sprintf( '<div id="recipe_step_%s" class="recipe-instruction%s" itemprop="recipeInstructions">%s%s</div>',
					$GLOBALS['trg_recipe_step_count'],
					$xclass ? ' ' . esc_attr( $xclass ) : '',
					sprintf( $num_box, number_format_i18n( $GLOBALS['trg_recipe_step_count'] ) ),
					trg_return_clean( $content )
				);

			// Store recipe instructions for use in JSON LD Schema
			if ( ! isset( $GLOBALS['trg_recipe_instructions'] ) ) {
				$GLOBALS['trg_recipe_instructions'] = array();
			}
			$GLOBALS['trg_recipe_instructions'][] = wp_strip_all_tags( do_shortcode( $content ) );

			return $out;
		}

		function trg_add_vc_templates() {
		    global $vct_prefix;
		    $trg = $this;

		    // Remove default templates
		    add_filter( 'vc_load_default_templates', function( $templates ) use ( $vct_prefix ) {
		        if ( apply_filters( "{$vct_prefix}_disable_builtin_templates", false ) ) {
		            return array();
				}
		        else {
		            return $templates;
				}
		    }, 11 );

		    // Add custom template
		    add_filter( 'vc_load_default_templates', function( $templates ) use ( $vct_prefix, $trg ) {
		        // Load templates from plugin /vc_templates directory
		        $templates = array_merge( $templates, $trg->trg_load_vc_templates(__DIR__ . "/vc_templates/*.php", 'vctm' ) );

		        // Load templates from theme
		        $templates = array_merge( $templates, $trg->trg_load_vc_templates( trailingslashit( get_stylesheet_directory() ) . 'vc_templates/*.php', 'theme' ) );

		        //Load additional templates from plugins or themes
		        foreach( apply_filters( "{$vct_prefix}_template_locations", array() ) as $additional_location )
		            $templates = array_merge( $templates, $trg->trg_load_vc_templates( trailingslashit( $additional_location ) . '*.php', 'plugin' ) );

		        return $templates;
		    }, 12 );
		}

		function trg_load_vc_templates( $folder = 'default_templates', $hook_prefix = 'vctm' ) {
		    global $vct_prefix;

		    $templates = array();

		    //Load default tempaltes
		    foreach( glob( $folder ) as $filename ) {
		        $filename_clean = basename( $filename, '.php' );

		        $data = array();
		        $data['name']       = __( apply_filters( "{$vct_prefix}_{$hook_prefix}_name_{$filename_clean}", $this->trg_prettify_name( $filename_clean ) ), apply_filters("{$vct_prefix}_textdomain", 'vc_template_manager' ) );
		        $data['weight']     = apply_filters( "{$vct_prefix}_{$hook_prefix}_weight_{$filename_clean}", apply_filters( "{$vct_prefix}_default_weight", 0 ) );
		        $data['custom_class'] = apply_filters( "{$vct_prefix}_{$hook_prefix}_class_{$filename_clean}", "vctm_{$hook_prefix}_{$filename_clean}" );
		        $data['content']    = apply_filters( "{$vct_prefix}_{$hook_prefix}_content_{$filename_clean}", file_get_contents( $filename ) );

		        $templates[] = $data;
		    }

		    return $templates;
		}
		
// Title Shortcode
		function trg_title( $atts, $content = null ) {
			extract( shortcode_atts( array(
				'type'				=> 'fontawesome',
				'icon_fontawesome' 	=> '',
				'icon_openiconic'	=> '',
				'icon_typicons'		=> '',
				'icon_entypo'		=> '',
				'icon_linecons'		=> '',
				'icon_monosocial'	=> '',
				'icon_material'		=> '',
				'htag' 				=> 'h2',
				'text'				=> '',
				'link'				=> '',
				'link_title'		=> '',
				'target'			=> false,
				'icon_color'		=> '',
				'title_color'		=> '',
				'xclass'			=> ''
			), $atts ) );
			
			vc_icon_element_fonts_enqueue( $type );

			$txt = $text ? sprintf( '<i%s class="trg-icon %s"></i><span%s class="title-text">%s</span>',
								$icon_color ? ' style="color:' . $icon_color . '"' : '',
								${'icon_' . $type},
								$title_color ? ' style="color:' . $title_color . '"' : '',
								esc_attr( $text )
							) : '';

			if ( $link && $txt ) {
				$txt = sprintf( '<a class="main-text" href="%s"%s%s>%s</a>',
							esc_url( $link ),
							$target ? ' target="_blank"' : '',
							$link_title ? ' title="' . esc_attr( $link_title ) . '"' : '',
							$txt
						);
			}			
			
			return sprintf( '<%1$s class="trg-title%2$s">%3$s</%1$s>',
						$htag,
						$xclass ? ' ' . esc_attr( $xclass ) : '',
						$txt						
					);
		}  		

		/**
		 * Prettifies an ugly file name
		 *
		 * @param $name
		 * @return string
		 */
		function trg_prettify_name( $name ) {
		    global $vct_prefix;

		    //Normalize spaces
		    $name = str_replace(array( '-', '_' ), ' ', $name );

		    $ret = '';
		    foreach( explode( ' ', $name ) as $word ) {
		        $ret .= ucfirst( $word ) . ' ';
			}

		    return rtrim( $ret );
		}

	}

	// Create new instance of class
	$total_recipe_generator = new Total_Recipe_Generator();

} // If not class exists
?>