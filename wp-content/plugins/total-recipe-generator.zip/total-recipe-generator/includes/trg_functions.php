<?php
/**
 * Total Recipe Generator Functions
 *
 * @package Total_Recipe_Generator
 * @since 1.0.0
 * @version 1.0.0
 */

// Let shortcodes inherit class properties of WPBakeryShortCodesContainer
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
	class WPBakeryShortCode_Trg_Recipe extends WPBakeryShortCodesContainer {}
}

if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
	class WPBakeryShortCode_Trg_Recipe_Method extends WPBakeryShortCodesContainer {}
}

// Register input type=number for VC shortcode map
function trg_vc_textfield_form_field_number( $settings, $value ) {
	$value = htmlspecialchars( $value );

	return '<input name="' . $settings['param_name']
	. '" class="wpb_vc_param_value wpb-textinput '
	. $settings['param_name'] . ' ' . $settings['type']
	. '" type="number" value="' . $value . '" min="' . $settings['min'] . '" max="' . $settings['max'] . '"/>';
}
vc_add_shortcode_param( 'textfield_num', 'trg_vc_textfield_form_field_number' );

// Register multiple dropdown field for VC shortcode map
function trg_vc_dropdown_form_field_multiple( $settings, $value ) {
	$output = '';
	$css_option = str_replace( '#', 'hash-', vc_get_dropdown_option( $settings, $value ) );
	$output .= '<select name="'
	           . $settings['param_name']
	           . '" class="wpb_vc_param_value wpb-input wpb-select '
	           . $settings['param_name']
	           . ' ' . $settings['type']
	           . ' ' . $css_option
	           . '" data-option="' . $css_option . '" multiple size="5">';
	$value_arr = explode( ',', $value );
	if ( ! empty( $settings['value'] ) ) {
		foreach ( $settings['value'] as $index => $data ) {
			if ( is_numeric( $index ) && ( is_string( $data ) || is_numeric( $data ) ) ) {
				$option_label = $data;
				$option_value = $data;
			} elseif ( is_numeric( $index ) && is_array( $data ) ) {
				$option_label = isset( $data['label'] ) ? $data['label'] : array_pop( $data );
				$option_value = isset( $data['value'] ) ? $data['value'] : array_pop( $data );
			} else {
				$option_value = $data;
				$option_label = $index;
			}
			$selected = '';
			$option_value_string = (string) $option_value;
			$value_string = (string) $value;
			if ( in_array( $data, $value_arr ) ) {
				$selected = ' selected="selected"';
			}
			$option_class = str_replace( '#', 'hash-', $option_value );
			$output .= '<option value="' . esc_attr( $option_value ) . '"' . $selected . '>'
			           . htmlspecialchars( $option_label ) . '</option>';
		}
	}
	$output .= '</select>';
	return $output;
}
vc_add_shortcode_param( 'dropdown_multiple', 'trg_vc_dropdown_form_field_multiple' );

/**
 * Create list item and links for items
 * selected for cuisine, course and cooking method
 *
 * @params $list_main (array), $list_other(array), $schema_prop(string), $link(boolean)
 * @return array
 */
if ( ! function_exists ( 'trg_create_list_items' ) ) :
	function trg_create_list_items( $list_main = '', $list_other = '', $schema_prop = '', $link = false ) {

		$rcu = $rcuo = $rcat = $rcato = $temp = array();
		$rcu_out = $rcato = $tag = $tag_link = '';

		$rcu = explode( ',', $list_main );
		if ( '' !== $list_other ) {
			$rcuo = explode( ',', $list_other );
		}
		$temp = array_merge( $rcu, $rcuo );
		if ( is_array( $temp ) ) {
			foreach( $temp as $rcu_item ) {
				if ( '' != $rcu_item ) {
					if ( $link ) {
						$tag_link = get_term_by( 'name', $rcu_item, 'post_tag' );
						$cat_link = get_term_by( 'name', $rcu_item, 'category' );

						if ( isset( $tag_link->term_id ) ) {
							$rcu_out .= sprintf( '<li class="cm-value link-enabled" itemprop="%1$s"><a href="%2$s" title="%3$s" target="_blank">%4$s</a></li>',
								$schema_prop,
								get_term_link( $tag_link->term_id, 'post_tag' ),
								sprintf( __( 'View all recipies tagged %s', 'trg' ), $rcu_item ),
								$rcu_item
							);
						}

						// Check if a category is available
						elseif ( isset( $cat_link->term_id ) ) {
							$rcu_out .= sprintf( '<li class="cm-value link-enabled" itemprop="%1$s"><a href="%2$s" title="%3$s" target="_blank">%4$s</a></li>',
								$schema_prop,
								get_term_link( $cat_link->term_id, 'category' ),
								sprintf( __( 'View all recipies in %s', 'trg' ), $rcu_item ),
								$rcu_item
							);
						}

						else {
							$rcu_out .= '<li class="cm-value" itemprop="' . $schema_prop . '">' . $rcu_item . '</li>';
						}
					}
					else {
						$rcu_out .= '<li class="cm-value" itemprop="' . $schema_prop . '">' . $rcu_item . '</li>';
					}
				}
			}
		}

		return array( 'html' => $rcu_out, 'arr' => $temp );

	}
endif;

/**
 * Create list item and links for items
 * selected for "suitable for diet"
 *
 * @params $list_main (array), $link(boolean)
 * @return array
 */
if ( ! function_exists ( 'trg_create_diet_items' ) ) :
	function trg_create_diet_items( $list_main = '', $list_other = '', $link = false ) {

		if ( '' == $list_main && '' == $list_other ) {
			return;
		}
		
		$allowed_schema = apply_filters( 'trg_allowed_diet_schema', array( 'Diabetic', 'Gluten Free', 'Halal', 'Hindu', 'Kosher', 'Low Calorie', 'Low Fat', 'Low Lactose', 'Low Salt', 'Vegan', 'Vegetarian' ) );

		$sfda = $sfdo = array();
		$rcu_out = '';
		$return_arr = array();
		
		$sfda = explode( ',', $list_main );
		if ( '' !== $list_other ) {
			$sfdo = explode( ',', $list_other );
		}
		$rcu = array_merge( $sfda, $sfdo );		

		if ( is_array( $rcu ) && ! empty( $rcu ) ) {
			foreach( $rcu as $rcu_item ) {
				$sfd = str_replace( ' ', '', $rcu_item );
				$rcu_item = trim( $rcu_item );
				$schema_prop = '';
				if ( in_array( $rcu_item, $allowed_schema ) ) {
					$schema_prop = '<link itemprop="suitableForDiet" href="http://schema.org/' . $sfd . 'Diet" />';
				}

				if ( $link ) {
					$tag_link = get_term_by( 'name', $rcu_item, 'post_tag' );
					$cat_link = get_term_by( 'name', $rcu_item, 'category' );

					// Check if a tag is available
					if ( isset( $tag_link->term_id ) ) {
						$rcu_out .= sprintf( '<li class="cm-value link-enabled">%1$s<a href="%2$s" title="%3$s" target="_blank">%4$s</a></li>',
							$schema_prop,
							get_term_link( $tag_link->term_id, 'post_tag' ),
							sprintf( __( 'View all recipies tagged %s', 'trg' ), $rcu_item ),
							$rcu_item
						);
					}

					// Check if a category is available
					elseif ( isset( $cat_link->term_id ) ) {
						$rcu_out .= sprintf( '<li class="cm-value link-enabled">%1$s<a href="%2$s" title="%3$s" target="_blank">%4$s</a></li>',
							$schema_prop,
							get_term_link( $cat_link->term_id, 'category' ),
							sprintf( __( 'View all recipies in %s', 'trg' ), $rcu_item ),
							$rcu_item
						);
					}

					// Else no link
					else {
						$rcu_out .= sprintf( '<li class="cm-value">%1$s%2$s</li>',
							$schema_prop,
							$rcu_item
						);
					}
				}
				else {
					$rcu_out .= sprintf( '<li class="cm-value">%1$s%2$s</li>',
						$schema_prop,
						$rcu_item
					);
				}
			}
		}
		if ( '' !== $rcu_out ) {
			$return_arr['html'] = $rcu_out;
		}
		if ( '' !== $rcu ) {
			$return_arr['arr'] = $rcu;
		}
		return $return_arr;
	}
endif;

/**
 * Create row of nutrient with nutritional value
 *
 * @params $nutrition (array)
 * @return string
 */
if ( ! function_exists ( 'trg_nutrient_items' ) ) :
	function trg_nutrient_items( $nutrition = array() ) {

		$nu_out = '';
		$schema_prop = '';

		if ( is_array( $nutrition ) ) {
			foreach( $nutrition as $nu ) {
				$nu_out .= '<li><span class="label">' . esc_attr( $nu->nutrient_label ) . '</span><span itemprop="' . esc_attr( $nu->nutrient ) . '">' . esc_attr( $nu->amount ). '</span></li>';
			}
		}
		return $nu_out;
	}
endif;

/**
 * Convert time in minutes into hour
 *
 * @params $time_in_min (string|int)
 * @return array
 */

if ( ! function_exists ( 'trg_time_convert' ) ) :
	function trg_time_convert( $time_in_min = '' ) {
		$hr = $min = 0;
		$arr = array( 'schema' => '', 'readable' => '' );
		$readable = $out = '';
		if ( isset( $time_in_min ) ) {
			if ( (int)$time_in_min >= 60 ) {
				$hr = floor( $time_in_min / 60 );
				$min = $time_in_min % 60;
			}

			else {
				$min = $time_in_min % 60;
			}

			if ( (int)$hr > 0 && (int)$min <= 0 ) {
				$out = $hr . 'H';
				$readable = sprintf( _x( '%s hr', 'xx hours', 'trg' ), number_format_i18n( $hr ) );
			}

			elseif ( (int)$hr <= 0 && (int)$min > 0 ) {
				$out = $min . 'M';
				$readable = sprintf( _x( '%s min', 'xx minutes', 'trg' ), number_format_i18n( $min ) );
			}

			elseif ( (int)$hr > 0 && (int)$min > 0 ) {
				$out = $hr . 'H' . $min . 'M';
				$readable = sprintf( _x( '%1$s hr %2$s min', 'xx hour yy minutes', 'trg' ), number_format_i18n( $hr ), number_format_i18n( $min ) );
			}

			$arr[ 'schema' ] = 'PT' . $out;
			$arr[ 'readable' ] = $readable;
		}
		return $arr;
	}
endif;

/**
 * Image resize using BFI Thumb
 *
 * @params
	$src 			(Image URL)
	$imgwidth 		(string|int)
	$imgheight 		(string|int)
	$imgcrop		(boolean)
	$imgquality 	(string|int|0 - 100)
	$imgcolor 		(hex color #000000 - #ffffff)
	$imggrayscale 	(boolean)
 * return Image URL
 */
if ( ! function_exists ( 'trg_image_resize' ) ) :
	function trg_image_resize( $src, $imgwidth, $imgheight, $imgcrop, $imgquality, $imgcolor, $imggrayscale ) {
		$params = array();

		// Validate boolean params
		$crop = ( '' == $imgcrop || 'false' == $imgcrop ) ? false : true;
		$grayscale = ( '' == $imggrayscale || 'false' == $imggrayscale ) ? false : true;

		// Params array
		if ( $crop ) {
			$params['crop'] = true;
		}

		if ( $grayscale ) {
			$params['grayscale'] = true;
		}

		if ( '' != $imgquality ) {
			if ( (int)$imgquality < 1 ) {
				$quality = 1;
			} elseif ( (int)$imgquality > 100 ) {
				$quality = 100;
			} else {
				$quality = $imgquality;
			}
			$params['quality'] = (int)$quality;
		}

		if ( '' != $imgcolor ) {
			$color = preg_match( '/#([a-f]|[A-F]|[0-9]){3}(([a-f]|[A-F]|[0-9]){3})?\b/', $imgcolor ) ? $imgcolor : '';
			$params['color'] = $color;
		}

		// Validate width and height
		if ( isset( $imgwidth ) && (int)$imgwidth > 4 && '' != $imgwidth ) {
			$params['width'] = $imgwidth;
		}

		if ( isset( $imgheight ) && (int)$imgheight > 4 && '' != $imgheight ) {
			$params['height'] = $imgheight;
		}

		if ( function_exists( 'bfi_thumb' ) && ! empty( $params ) ) {
			return bfi_thumb( $src, $params );
		} else {
			return $src;
		}
	}
endif;

/**
 * Remove automatic p and br tags from shortcode output
 */
if ( ! function_exists ( 'trg_return_clean' ) ) :
	function trg_return_clean( $content, $p_tag = false, $br_tag = false ) {
		$content = preg_replace( '#^<\/p>|^<br \/>|<p>$#', '', $content );

		if ( $br_tag ) {
			$content = preg_replace( '#<br \/>#', '', $content );
		}

		if ( $p_tag ) {
			$content = preg_replace( '#<p>|</p>#', '', $content );
		}

		return do_shortcode( shortcode_unautop( trim( $content ) ) );
	}
endif;


/**
 * Add OG meta tags in head section
 * Required for social sharing feature
 */
function trg_add_og_site_tag() {
	if ( apply_filters( 'trg_add_og_tags', true ) ) {
		if ( is_single() || is_page() ) {
			global $post;
			setup_postdata( $post );
			$image = '';
			if ( has_post_thumbnail( $post->ID ) ) {
				$image = wp_get_attachment_url( get_post_thumbnail_id( $post->ID ) );
			}
			?>

			<!-- OG tags for social sharing -->
			<meta property="og:title" content="<?php echo esc_attr( get_the_title() ); ?>"/>
			<meta property="og:type" content="article"/>
			<meta property="og:image" content="<?php echo esc_url( get_post_meta( $post->ID, 'trg_share_image', true ) ); ?>"/>
			<meta property="og:url" content="<?php echo esc_url( get_permalink() ); ?>"/>
			<meta property="og:description" content="<?php echo strip_tags( get_post_meta( $post->ID, 'trg_share_desc', true ) ); ?>"/>
			<meta property="og:site_name" content="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>"/>
			<?php wp_reset_postdata();
		}
	}
}
add_action( 'wp_head', 'trg_add_og_site_tag', 99 );

/**
 * Social Sharing feature for recipe post
 */
if ( ! function_exists( 'trg_social_sharing' ) ) :
	function trg_social_sharing( $sharing_buttons, $social_sticky = false ) {
		global $post;
		setup_postdata( $post );

		// Set variables
		$out = '';
		$list = '';
		$share_image = '';
		$protocol = is_ssl() ? 'https' : 'http';

		if ( has_post_thumbnail( $post->ID ) ) {
			$share_image = wp_get_attachment_url( get_post_thumbnail_id( $post->ID ), 'full' );
		}

		$share_content = strip_tags( get_the_excerpt() );
		$btn_count = count( $sharing_buttons );

		if ( in_array( 'whatsapp', $sharing_buttons ) ) {
			if ( ! wp_is_mobile() ) {
				$btn_count--;
			}
		}

		$out .= sprintf( '<div id="trg-social-sharing" class="trg-sharing-container%s btns-%s">',
			$social_sticky ? ' trg-social-sticky' : '',
			$btn_count
		);

		$out .= '<ul class="trg-sharing clearfix">';

		foreach ( $sharing_buttons as $button ) {

			switch( $button ) {

				case 'twitter':
					$list .= sprintf( '<li class="trg-twitter"><a href="%s://twitter.com/home?status=%s" target="_blank" title="%s"><i class="icn icn-twitter"></i><span class="sr-only">twitter</span></a></li>', esc_attr( $protocol ), urlencode( esc_url( get_permalink() ) ), esc_attr__( 'Share on twitter', 'trg' ) );
				break;

				case 'facebook':
					$list .= sprintf( '<li class="trg-facebook"><a href="%s://www.facebook.com/sharer/sharer.php?u=%s" target="_blank" title="%s"><i class="icn icn-facebook"></i><span class="sr-only">facebook</span></a></li>', esc_attr( $protocol ), urlencode( esc_url( get_permalink() ) ), esc_attr__( 'Share on facebook', 'trg' ) );
				break;

				case 'whatsapp':
					if ( wp_is_mobile() ) {
						$list .= sprintf( '<li class="trg-whatsapp"><a href="whatsapp://send?text=%s" title="%s" data-action="share/whatsapp/share"><i class="icn icn-whatsapp"></i><span class="sr-only">whatsapp</span></a></li>', urlencode( esc_url( get_permalink() ) ), esc_attr__( 'Whatsapp', 'trg' ) );
					}
				break;

				case 'googleplus':
					$list .= sprintf( '<li class="trg-gplus"><a href="%s://plus.google.com/share?url=%s" target="_blank" title="%s"><i class="icn icn-google-plus"></i><span class="sr-only">google+</span></a></li>', esc_attr( $protocol ), urlencode( esc_url( get_permalink() ) ), esc_attr__( 'Share on Google+', 'trg' ) );
				break;

				case 'linkedin':
					$list .= sprintf( '<li class="trg-linkedin"><a href="%s://www.linkedin.com/shareArticle?mini=true&amp;url=%s" target="_blank" title="%s"><i class="icn icn-linkedin"></i><span class="sr-only">linkedin</span></a></li>', esc_attr( $protocol ), urlencode( esc_url( get_permalink() ) ), esc_attr__( 'Share on LinkedIn', 'trg' ) );
				break;

				case 'pinterest':
					$list .= sprintf( '<li class="trg-pint"><a href="%s://pinterest.com/pin/create/button/?url=%s&amp;media=%s" target="_blank" title="%s"><i class="icn icn-pinterest"></i><span class="sr-only">pinterest</span></a></li>',
						esc_attr( $protocol ),
						urlencode( esc_url( get_permalink() ) ),
						esc_url( $share_image ),
						esc_attr__( 'Pin it', 'trg' )
					);
				break;

				case 'vkontakte':
					$list .= sprintf( '<li class="trg-vk"><a href="%s://vkontakte.ru/share.php?url=%s" target="_blank" title="%s"><i class="icn icn-vk"></i><span class="sr-only">vkontakte</span></a></li>', esc_attr( $protocol ), urlencode( esc_url( get_permalink() ) ), esc_attr__( 'Share via VK', 'trg' ) );
				break;

				case 'email':
					$list .= sprintf( '<li class="trg-mail"><a href="mailto:someone@example.com?Subject=%s" title="%s"><i class="icn icn-envelope"></i><span class="sr-only">email</span></a></li>', urlencode( esc_attr( get_the_title() ) ), esc_attr__( 'Email this', 'trg' ) );

				break;

				case 'print':
					$list .= sprintf( '<li class="trg-print"><a id="trg-print-btn" href="#" title="%s"><i class="icn icn-print"></i><span class="sr-only">print</span></a></li>', esc_attr__( 'Print', 'trg' ) );
				break;

				case 'reddit':
					$list .= sprintf( '<li class="trg-reddit"><a href="//www.reddit.com/submit" onclick="window.location = \'//www.reddit.com/submit?url=\' + encodeURIComponent(window.location); return false" title="%s"><i class="icn icn-reddit"></i><span class="sr-only">reddit</span><span class="sr-only">reddit</span></a></li>', esc_attr__( 'Reddit', 'trg' ) );
				break;
			} // switch

		} // foreach

		// Support extra meta items via action hook
		ob_start();
		do_action( 'trg_sharing_buttons_li' );
		$out .= ob_get_contents();
		ob_end_clean();

		$out .= $list . '</ul></div>';

		return $out;
	}
endif;
?>