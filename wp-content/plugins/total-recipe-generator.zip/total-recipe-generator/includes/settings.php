<?php
/**
 * TRG Settings Page in Admin
 *
 * Uses TRG_Settings_API Class
 */

if ( ! class_exists( 'Generate_TRG_Settings' ) ) :

	class Generate_TRG_Settings {
	
		private $settings_api;
	
		function __construct() {
			$this->settings_api = new TRG_Settings_API;
	
			add_action( 'admin_init', array($this, 'admin_init') );
			add_action( 'admin_menu', array($this, 'admin_menu') );
		}
	
		function admin_init() {
	
			//set the settings
			$this->settings_api->set_sections( $this->get_settings_sections() );
			$this->settings_api->set_fields( $this->get_settings_fields() );
	
			//initialize settings
			$this->settings_api->admin_init();
		}
	
		function admin_menu() {
			add_options_page( 'Total Recipe Generator Settings', 'Total Recipe Generator', 'manage_options', 'trg_settings', array($this, 'plugin_page') );
		}
	
		function get_settings_sections() {
			$sections = array(
				array(
					'id' => 'trg_adspots',
					'title' => esc_attr__( 'Ad Spots', 'trg' )
				),
				array(
					'id' => 'trg_display',
					'title' => esc_attr__( 'Display', 'trg' )
				),
				array(
					'id' => 'trg_social',
					'title' => esc_attr__( 'Social', 'trg' )
				),
				array(
					'id' => 'trg_labels',
					'title' => esc_attr__( 'Labels', 'trg' )
				),
			);
			return $sections;
		}
	
		/**
		 * Returns all the settings fields
		 *
		 * @return array settings fields
		 */
		function get_settings_fields() {
			$settings_fields = array(
				'trg_adspots' => array(
					array(
						'name'              => 'ad_spot_1',
						'label'             => esc_attr__( 'Global ad spot 1', 'trg' ),
						'desc'              => esc_attr__( 'Global ad spot to be shown above ingredients section. Individual recipe post can override this setting', 'trg' ),
						'type'              => 'textarea',
						'default'           => ''
					),

					array(
						'name'              => 'ad_spot_2',
						'label'             => esc_attr__( 'Global ad spot 2', 'trg' ),
						'desc'              => esc_attr__( 'Global ad spot to be shown above methods section. Individual recipe post can override this setting', 'trg' ),
						'type'              => 'textarea',
						'default'           => ''
					),

					array(
						'name'              => 'ad_spot_3',
						'label'             => esc_attr__( 'Global ad spot 3', 'trg' ),
						'desc'              => esc_attr__( 'Global ad spot to be shown after nutrition table. Individual recipe post can override this setting', 'trg' ),
						'type'              => 'textarea',
						'default'           => ''
					)
				),
				'trg_display' => array(
					array(
						'name'    => 'icon_color',
						'label'   => esc_attr__( 'Icons Color', 'trg' ),
						'desc'    => esc_attr__( 'Choose a color for heading icons', 'trg' ),
						'type'    => 'color'
					),

					array(
						'name'    => 'heading_color',
						'label'   => esc_attr__( 'Heading Color', 'trg' ),
						'desc'    => esc_attr__( 'Choose a color for headings', 'trg' ),
						'type'    => 'color'
					),

					array(
						'name'    => 'tags_bg',
						'label'   => esc_attr__( 'Tag links background', 'trg' ),
						'desc'    => esc_attr__( 'Choose a background color for tag links', 'trg' ),
						'type'    => 'color'
					),

					array(
						'name'    => 'tags_color',
						'label'   => esc_attr__( 'Tag links foreground', 'trg' ),
						'desc'    => esc_attr__( 'Choose a foreground text color for tag links', 'trg' ),
						'type'    => 'color'
					),

					array(
						'name'    => 'tags_bg_hover',
						'label'   => esc_attr__( 'Tag links background hover', 'trg' ),
						'desc'    => esc_attr__( 'Choose a hover background color for tag links', 'trg' ),
						'type'    => 'color'
					),

					array(
						'name'    => 'tags_color_hover',
						'label'   => esc_attr__( 'Tag links hover color', 'trg' ),
						'desc'    => esc_attr__( 'Choose a hover color for tag links', 'trg' ),
						'type'    => 'color'
					),

					array(
						'name'    => 'label_color',
						'label'   => esc_attr__( 'Text labels color', 'trg' ),
						'desc'    => esc_attr__( 'Choose a color for text labels in recipe meta', 'trg' ),
						'type'    => 'color'
					),

					array(
						'name'    => 'highlights',
						'label'   => esc_attr__( 'Text highlights color', 'trg' ),
						'desc'    => esc_attr__( 'Choose a highlight color for text in recipe meta', 'trg' ),
						'type'    => 'color'
					),

					array(
						'name'    => 'count_color',
						'label'   => esc_attr__( 'Color for number count', 'trg' ),
						'desc'    => esc_attr__( 'Choose a color for number count in recipe method', 'trg' ),
						'type'    => 'color'
					),

					array(
						'name'    => 'tick_color',
						'label'   => esc_attr__( 'Ingredients tick color', 'trg' ),
						'desc'    => esc_attr__( 'Choose a color for tick icon in ingredients section', 'trg' ),
						'type'    => 'color'
					)
				),

				'trg_social' => array(
					array(
						'name'              => 'social_heading',
						'label'             => esc_attr__( 'Social sharing heading', 'trg' ),
						'desc'              => esc_attr__( 'Provide a heading for social sharing buttons', 'trg' ),
						'type'              => 'text',
						'default'           => ''
					),

					array(
						'name'              => 'social_buttons',
						'label'             => esc_attr__( 'Social Sharing buttons', 'trg' ),
						'desc'              => esc_attr__( 'Select social share buttons to show at the end of recipe', 'trg' ),
						'type'              => 'select_multiple',
						'default'           => '',
						'options'			=> array(
							'twitter'		=> __( 'Twitter', 'trg' ),
							'facebook'	 	=> __( 'Facebook', 'trg' ),
							'whatsapp'		=> __( 'WhatsApp', 'trg' ),
							'googleplus'	=> __( 'Google Plus', 'trg' ),
							'linkedin'	 	=> __( 'LinkedIn', 'trg' ),
							'pinterest'	 	=> __( 'Pinterest', 'trg' ),
							'vkontakte'	 	=> __( 'VKOntakte', 'trg' ),
							'email'	 		=> __( 'Email', 'trg' ),
							'print'	 		=> __( 'Print', 'trg' ),
							'reddit'	 	=> __( 'Reddit', 'trg' )
						)
					),

					array(
						'name'  => 'social_sticky',
						'label' => esc_attr__( 'Sticky Social Buttons', 'trg' ),
						'desc'  => esc_attr__( 'Make social buttons sticky on mobile', 'trg' ),
						'type'  => 'checkbox'
					),
				),
				'trg_labels' => array(
					array(
						'name'              => 'label_cuisine',
						'label'             => esc_attr__( 'Cuisine Label', 'trg' ),
						'desc'              => esc_attr__( 'Provide a label text for Cuisine.', 'trg' ),
						'type'              => 'text',
						'default'           => __( 'Cuisine', 'trg' )
					),

					array(
						'name'              => 'label_course',
						'label'             => esc_attr__( 'Course Label', 'trg' ),
						'desc'              => esc_attr__( 'Provide a label text for Course.', 'trg' ),
						'type'              => 'text',
						'default'           => __( 'Course', 'trg' )
					),

					array(
						'name'              => 'label_cm',
						'label'             => esc_attr__( 'Cooking Method Label', 'trg' ),
						'desc'              => esc_attr__( 'Provide a label text for Cooking Method.', 'trg' ),
						'type'              => 'text',
						'default'           => __( 'Cooking Method', 'trg' )
					),

					array(
						'name'              => 'label_sfd',
						'label'             => esc_attr__( 'Suitable for Diet Label', 'trg' ),
						'desc'              => esc_attr__( 'Provide a label text for Suitable for Diet.', 'trg' ),
						'type'              => 'text',
						'default'           => __( 'Suitable for Diet', 'trg' )
					),

					array(
						'name'              => 'label_kw',
						'label'             => esc_attr__( 'Keywords Label', 'trg' ),
						'desc'              => esc_attr__( 'Provide a label text for keywords/tags.', 'trg' ),
						'type'              => 'text',
						'default'           => __( 'Keywords', 'trg' )
					),
				)									
			);
	
			return $settings_fields;
		}
	
		function plugin_page() {
			echo '<div class="wrap">';
			echo '<h1>' . esc_attr__( 'Total Recipe Generator Settings', 'trg' ) . '</h1>';
			$this->settings_api->show_navigation();
			$this->settings_api->show_forms();
	
			echo '</div>';
		}
	
		/**
		 * Get all the pages
		 *
		 * @return array page names with key value pairs
		 */
		function get_pages() {
			$pages = get_pages();
			$pages_options = array();
			if ( $pages ) {
				foreach ($pages as $page) {
					$pages_options[$page->ID] = $page->post_title;
				}
			}
	
			return $pages_options;
		}
	}
	
	$generate_trg_settings = new Generate_TRG_Settings();

endif;