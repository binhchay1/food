<?php
/**
 * Template part for the output of recipe shortcode
 *
 * You can override this template by
 * copying the file to /wp-content/theme_folder/trg_templates/recipe.php
 *
 * @package Total_Recipe_Generator
 * @since 1.0.0
 * @version 1.6.7
 */

$meta = '';
$rp_json = array( '@context' => 'http://schema.org', '@type' => 'Recipe' );
$website_json = array( '@context' => 'http://schema.org', '@type' => 'Website', 'name' => get_bloginfo( 'name' ), 'alternateName' => get_bloginfo( 'description' ), 'url' => esc_url( home_url( '/' ) ) );


/**
 * Delete duplicate post meta keys
 * generated in versions before 1.1.0
 */
delete_post_meta( get_the_ID(), 'trg_share_image' );
delete_post_meta( get_the_ID(), 'trg_share_desc' );

/**
 * Add post meta only if doesn't exist
 */
$post_custom_keys = get_post_custom_keys( get_the_ID() );
if ( isset( $post_custom_keys ) && is_array( $post_custom_keys ) && ! in_array( 'trg_share_image', $post_custom_keys ) ) {
	add_post_meta( get_the_ID(), 'trg_share_image', '' );
}

if ( isset( $post_custom_keys ) && is_array( $post_custom_keys ) && ! in_array( 'trg_share_desc', $post_custom_keys ) ) {
	add_post_meta( get_the_ID(), 'trg_share_desc', '' );
}

printf( '<div class="trg-recipe%s" itemscope itemtype="http://schema.org/Recipe">', $has_custom_css ? ' trg_custom_css_' . $trg_css_count : '' );

    $name 			= ( 'custom' == $name_src && '' != $name_txt ) ? $name_txt : get_the_title();
	$author 		= ( 'custom' == $author_src && '' != $author_name ) ? $author_name : get_the_author();
	$author_url 	= ( '' !== $author_url ) ? $author_url : get_author_posts_url( get_the_author_meta( 'ID' ) );

	$img_obj = $image = '';
	if ( has_post_thumbnail() ) {
		$img_obj = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' );
		$image = $img_obj[0];
	}
	if ( 'media_lib' == $img_src && '' != $img_lib ) {
		$image = wp_get_attachment_image_src ( $img_lib, 'full' );
		$image = $image[0];
	}
	elseif ( 'ext' == $img_src && '' != $img_ext ) {
		$image = $img_ext;
	}

	if ( function_exists( 'trg_image_resize' ) && 'ext' !== $img_src ) {
		$image = trg_image_resize( $image, $imgwidth, $imgheight, $imgcrop, $imgquality, '', '' );
	}

	/**
	 * Update post meta
	 * @meta_key 'trg_share_image'
	 *
	 * Used to set og:image tag in head
	 * Used in trg_add_og_site_tag() function
	 */
	if ( '' != $image ) {
		update_post_meta( get_the_ID(), 'trg_share_image', $image );
	}

	// Add to JSON
	$rp_json['name'] = esc_attr( $name );
	$rp_json['author'] = esc_attr( $author );
	$rp_json['image'] = esc_url( $image );
	$rp_json['datePublished'] = esc_attr( get_the_date( 'c' ) );
	$rp_json['url'] = esc_url( get_permalink() );

	// Output URL Schema
	echo '<meta itemprop="url" content="' . esc_url( get_permalink() ) . '" />';

	// Recipe heading
	if ( $hide_name ) {
		printf( '<meta itemprop="name" content="%s" />',
			esc_attr( $name )
		);
	} else {
		printf( '<h2 class="entry-title recipe-title" itemprop="name">%s</h2>',
			esc_attr( $name )
		);
	}

	// Author and date meta
	if ( $hide_date ) {
		printf( '<meta itemprop="datePublished" content="%s" />',
			esc_attr( get_the_time( get_option( 'date_format' ) ) )
		);
	}
	if ( $hide_author ) {
		printf( '<meta itemprop="author" content="%s" />',
			esc_attr( $author )
		);
	}
	
	if ( ! $hide_author || ! $hide_date ) {
		echo '<ul class="recipe-meta">';
		if ( ! $hide_date ) {
			printf( '<li itemprop="datePublished" class="post-date">%s</li>',
				esc_attr( get_the_time( get_option( 'date_format' ) ) )
			);
		}
		if ( ! $hide_author ) {
			printf( '<li itemprop="author" class="post-author"><a href="%s">%s</a></li>',
				esc_url( $author_url ),
				esc_attr( $author )
			);
		}
		echo '</ul>';
	}

	// Featured image
 	if ( '' != $image ) {
		if ( '' !== $img_caption ) {
			printf( '<div class="wp-caption recipe-image%s%s"><img class="trg-img" itemprop="image" src="%s" alt="%s" /><p class="wp-caption-text">%s</p></div>',
				$hide_img ? ' print-only' : '',
				'none' !== $img_align ? ' align' . esc_attr( $img_align ) : '',
				esc_url( $image ),
				esc_attr( $img_alt ),
				esc_attr( $img_caption )
			);
		}
		else {
			printf( '<img class="trg-img recipe-image%s%s" itemprop="image" src="%s" alt="%s"/>',
				$hide_img ? ' print-only' : '',
				'none' !== $img_align ? ' align' . esc_attr( $img_align ) : '',
				esc_url( $image ),
				esc_attr( $img_alt )
			);
		}
	}

	// Recipe summary
	if ( $hide_summary) {
		printf( '<meta itemprop="description" content="%s" />',
			stripslashes( do_shortcode( $summary ) )
		);
	} else {
		printf( '<h3 class="recipe-summary" itemprop="description">%s</h3>',
			stripslashes( do_shortcode( $summary ) )
		);
	}

	/**
	 * Update post meta
	 * @meta_key 'trg_share_desc'
	 *
	 * Used to set og:description tag in head
	 * Used in trg_add_og_site_tag() function
	 */
	if ( '' != $summary ) {
		update_post_meta( get_the_ID(), 'trg_share_desc', $summary );
	}

	$rp_json['description'] = ( '' != $summary ) ? stripslashes( do_shortcode( $summary ) ) : '';


 	// Prep and cooking time meta
	if ( '' != $prep_time && '' != $cook_time ) {
		$total_time = trg_time_convert( (int)$prep_time + (int)$cook_time );
	}
	else {
		$total_time = trg_time_convert( (int)$total_time );
	}	
	$prep_time = trg_time_convert( (int)$prep_time );
	$cook_time = trg_time_convert( (int)$cook_time );

	$rp_json['cookTime'] = esc_attr( $prep_time[ 'schema' ] );
	$rp_json['prepTime'] = esc_attr( $cook_time[ 'schema' ] );
	$rp_json['totalTime'] = esc_attr( $total_time[ 'schema' ] );
	$rp_json['recipeYield'] = esc_attr( $recipe_yield );

	if ( '' !== $prep_time[ 'readable' ] || '' !== $cook_time[ 'readable' ] || '' !== $total_time[ 'readable' ] || '' !== $recipe_yield  || '' !== $serving_size || '' !== $calories ) {
		echo '<ul class="info-board">';
	
			if ( '' !== $prep_time[ 'readable' ] ) {
				echo sprintf( '<li class="prep-time"><meta itemprop="prepTime" content="%s"><span class="ib-label">%s</span><span class="ib-value">%s</span></li>',
					esc_attr( $prep_time[ 'schema' ] ),
					__( 'Prep Time', 'trg' ),
					esc_attr( $prep_time[ 'readable' ] )
				);
			}
	
			if ( '' !== $cook_time[ 'readable' ] ) {
				echo sprintf( '<li class="cook-time"><meta itemprop="cookTime" content="%s"><span class="ib-label">%s</span><span class="ib-value">%s</span></li>',
					esc_attr( $cook_time[ 'schema' ] ),
					__( 'Cook Time', 'trg' ),
					esc_attr( $cook_time[ 'readable' ] )
				);
			}
	
			if ( '' !== $total_time[ 'readable' ] ) {
				echo sprintf( '<li class="total-time"><meta itemprop="totalTime" content="%s"><span class="ib-label">%s</span><span class="ib-value">%s</span></li>',
					esc_attr( $total_time[ 'schema' ] ),
					__( 'Total Time', 'trg' ),
					esc_attr( $total_time[ 'readable' ] )
				);
			}
	
			if ( '' !== $recipe_yield ) {
				echo sprintf( '<li class="recipe-yield"><span class="ib-label">%s</span><span class="ib-value" itemprop="recipeYield">%s</span></li>',
					_x( 'Yield', 'Recipe yield or outcome', 'trg' ),
					esc_attr( $recipe_yield )
				);
			}
			
			if ( '' !== $serving_size ) {
				echo sprintf( '<li class="serving-size"><span class="ib-label">%s</span><span class="ib-value">%s</span></li>',
					__( 'Serving Size', 'trg' ),
					esc_attr( $serving_size )
				);
			}		
	
			if ( '' !== $calories ) {
				echo sprintf( '<li class="recipe-cal"><span class="ib-label">%s</span><span class="ib-value">%s</span></li>',
					_x( 'Energy', 'Label for recipe calories', 'trg' ),
					sprintf( _x( '%s cal', 'xx calories', 'trg' ), number_format_i18n( (int)$calories ) )
				);
			}
			
			if ( '' !== $total_cost ) {
				echo sprintf( '<li class="total-cost"><span class="ib-label">%s</span><span class="ib-value">%s</span></li>',
					_x( 'Total Cost', 'Label for total cost', 'trg' ),
					esc_attr( $total_cost )
				);
			}
			
			if ( '' !== $cost_per_serving ) {
				echo sprintf( '<li class="cost-per-serving"><span class="ib-label">%s</span><span class="ib-value">%s</span></li>',
					_x( 'Cost per Serving', 'Label for cost per serving', 'trg' ),
					esc_attr( $cost_per_serving )
				);
			}
	
		echo '</ul>';

	}
	
 	// Cuisine meta
	$rcu 		= trg_create_list_items( $recipe_cuisine, $recipe_cuisine_other, 'recipeCuisine', true );
	$rcat 		= trg_create_list_items( $recipe_category, $recipe_category_other, 'recipeCategory', true );
	$rmethod 	= trg_create_list_items( $cooking_method, '', 'cookingMethod', true );
	$sfd 		= trg_create_diet_items( $suitable_for_diet, $suitable_for_diet_other, true );

	$rp_json['recipeCuisine'] 	= $rcu['arr'];
	$rp_json['recipeCategory'] 	= $rcat['arr'];
	$rp_json['cookingMethod'] 	= $rmethod['arr'];
	$rp_json['suitableForDiet'] = $sfd['arr'];


	if ( '' !== $rcu || '' !== $rcat || '' !== $rmethod || '' !== $sfd || ( $show_tags && get_the_tags() ) ) {
		echo '<ul class="cuisine-meta">';

			if ( '' !== $rcu ['html']) {
				echo sprintf( '<li><span class="cm-label">%s</span><ul class="cm-items">%s</ul></li>',
					isset( $labels[ 'label_cuisine' ] ) ? $labels[ 'label_cuisine' ] : __( 'Cuisine', 'trg' ),
					$rcu['html']
				);
			}

			if ( '' !== $rcat['html'] ) {
				echo sprintf( '<li><span class="cm-label">%s</span><ul class="cm-items">%s</ul></li>',
					isset( $labels[ 'label_course' ] ) ? $labels[ 'label_course' ] : __( 'Course', 'trg' ),
					$rcat['html']
				);
			}

			if ( '' !== $rmethod['html'] ) {
				echo sprintf( '<li><span class="cm-label">%s</span><ul class="cm-items">%s</ul></li>',
					isset( $labels[ 'label_cm' ] ) ? $labels[ 'label_cm' ] : __( 'Cooking Method', 'trg' ),
					$rmethod['html']
				);
			}

			if ( isset( $sfd ) && '' !== $sfd['html'] ) {
				echo sprintf( '<li><span class="cm-label">%s</span><ul class="cm-items">%s</ul></li>',
					isset( $labels[ 'label_sfd' ] ) ? $labels[ 'label_sfd' ] : __( 'Suitable for Diet', 'trg' ),
					$sfd['html']
				);
			}

			// Tags Meta
			if ( $show_tags && get_the_tags() ) {
				echo sprintf( '<li><span class="cm-label">%s</span>%s</li>',
					isset( $labels[ 'label_kw' ] ) ? $labels[ 'label_kw' ] : __( 'Keywords', 'trg' ),
					get_the_tag_list('<ul class="cm-items recipe-tags" itemprop="keywords"><li class="cm-value link-enabled">','</li><li class="cm-value link-enabled">','</li></ul>' )
				);
			}

		echo '</ul>';
		// Show keywords as hidden schema
		if ( $tags_schema_only && get_the_tags() ) {
			$posttags = get_the_tags();
			if ( $posttags && is_array( $posttags ) ) {
				echo '<meta itemprop="keywords" content="';
				foreach( $posttags as $tag ) {
					echo $tag->name . ', '; 
				}
			}
			echo '" />';
			// Add to JSON LD microdata
		}

		if ( ( $show_tags || $tags_schema_only ) && get_the_tags() ) {
			$posttags = get_the_tags();
			if ( $posttags && is_array( $posttags ) ) {
				$tags_arr = array();
				foreach( $posttags as $tag ) {
					$tags_arr[] = $tag->name; 
				}
			}
			$rp_json['keywords'] = $tags_arr;
		}
	}
	
	// Ad Spot 1
	if ( '' != $ad_spot_1 ) {
		echo '<div class="trg-ad-spot ad-spot-1">' . do_shortcode( rawurldecode( base64_decode( strip_tags( $ad_spot_1 ) ) ) ) . '</div>';
	} elseif ( isset( $ad_spots['ad_spot_1'] ) && '' !== $ad_spots['ad_spot_1'] ) {
		echo '<div class="trg-ad-spot ad-spot-1">' . wp_kses_post( do_shortcode( $ad_spots['ad_spot_1'] ) ) . '</div>';
	}
	
	?>

    <div class="ingredients-section clearfix">
		<?php
        // Ingredients
        $ing_list = '';
		$ing_json = array();

        if ( '' !== $ing_heading ) {
			echo '<h3 class="recipe-heading ing-title">' . esc_html( $ing_heading ) . '</h3>';
		}

		$ings = vc_param_group_parse_atts( $ingredients );

        if ( isset( $ings ) && is_array( $ings ) ) {
			foreach ( $ings as $ing ) {

				$ing_list = explode( "\n", str_replace("\r", "", $ing['list'] ) );

				if ( isset( $ing['title'] ) && '' != $ing['title'] ) {
					echo '<p class="list-subhead">' . $ing['title'] . '</p>';
				}

				if ( ! empty( $ing_list ) && is_array( $ing_list ) ) {
					echo '<ul class="ing-list">';
					foreach ( $ing_list as $list_item ) {
						echo '<li itemprop="recipeIngredient">' . $list_item . '</li>';
						$ing_json[] = $list_item;
					}
					echo '</ul>';
				}
			}
		}

		$rp_json['recipeIngredient'] = $ing_json;
        ?>
    </div><!-- /.ingredients-section -->

    <?php
	// Ad Spot 2
	if ( '' != $ad_spot_2 ) {
		echo '<div class="trg-ad-spot ad-spot-2">' . do_shortcode( rawurldecode( base64_decode( strip_tags( $ad_spot_2 ) ) ) ) . '</div>';
	} elseif ( isset( $ad_spots['ad_spot_2'] ) && '' !== $ad_spots['ad_spot_2'] ) {
		echo '<div class="trg-ad-spot ad-spot-2">' . wp_kses_post( do_shortcode( $ad_spots['ad_spot_2'] ) ) . '</div>';
	}
	
	if ( '' != $content ) {
	?>
        <div class="method-section clearfix">
            <?php
            // Method (Instructions)
            $num_class = '';
            $step_count = 1;
            if ( $enable_numbering ) {
				$num_class = ' number-enabled';
            }

            if ( '' !== $method_heading ) {
                echo '<h3 class="recipe-heading ins-title">' . esc_html( $method_heading ) . '</h3>';
            }

			echo '<div class="recipe-instructions' . $num_class . '">' . do_shortcode( $content ) . '</div>';
			
			// Reset global count for method steps
			$GLOBALS['trg_recipe_step_count'] = 0;
			
			// Add instructions to JSON
			if ( isset( $GLOBALS['trg_recipe_instructions'] ) ) {
				$rp_json['recipeInstructions'] = $GLOBALS['trg_recipe_instructions'];
			}

			// Reset Instructions
			unset( $GLOBALS['trg_recipe_instructions'] );
            ?>
        </div><!-- /.method-section -->
    <?php
	}

	// Other notes
	if ( '' !== $other_notes ) {
		echo '<div class="recipe-other-notes">' . trg_return_clean( do_shortcode( $other_notes ) ) . '</div>';
	}

  	// Nutrition
	if ( ! $hide_nutrition ) {
		 	// Nutrition
	$nutrition_facts = apply_filters( 'trg_nutrition_facts_list', array(
		array(
			'id'			=> 'total_fat',
			'label'			=> __( 'Total Fat', 'trg' ),
			'schema'		=> 'fatContent',
			'liclass'		=> false,
			'labelclass'	=> 'font-bold',
			'sv'			=> apply_filters( 'total_fat_sv', 78 ),
			'unit'			=> 'g'
		),
		array(
			'id'			=> 'saturated_fat',
			'label'			=> __( 'Saturated Fat', 'trg' ),
			'schema'		=> 'saturatedFatContent',
			'liclass'		=> 'nt-sublevel-1',
			'labelclass'	=> false,
			'sv'			=> apply_filters( 'saturated_fat_sv', 20 ),
			'unit'			=> 'g'
		),
		array(
			'id'			=> 'trans_fat',
			'label'			=> __( 'Trans Fat', 'trg' ),
			'schema'		=> 'transFatContent',
			'liclass'		=> 'nt-sublevel-1',
			'labelclass'	=> false,
			'sv'			=> false,
			'unit'			=> 'g'
		),
		array(
			'id'			=> 'polyunsat_fat',
			'label'			=> __( 'Polyunsaturated Fat', 'trg' ),
			'schema'		=> 'unsaturatedFatContent',
			'liclass'		=> 'nt-sublevel-1',
			'labelclass'	=> false,
			'sv'			=> false,
			'unit'			=> 'g'
		),
		array(
			'id'			=> 'monounsat_fat',
			'label'			=> __( 'Monounsaturated Fat', 'trg' ),
			'schema'		=> 'unsaturatedFatContent',
			'liclass'		=> 'nt-sublevel-1',
			'labelclass'	=> false,
			'sv'			=> false,
			'unit'			=> 'g'
		),
		array(
			'id'			=> 'cholesterol',
			'label'			=> __( 'Cholesterol', 'trg' ),
			'schema'		=> 'cholesterolContent',
			'liclass'		=> '',
			'labelclass'	=> 'font-bold',
			'sv'			=> apply_filters( 'cholesterol_sv', 300 ),
			'unit'			=> 'mg'
		),
		array(
			'id'			=> 'sodium',
			'label'			=> __( 'Sodium', 'trg' ),
			'schema'		=> 'sodiumContent',
			'liclass'		=> '',
			'labelclass'	=> 'font-bold',
			'sv'			=> apply_filters( 'sodium_sv', 2300 ),
			'unit'			=> 'mg'
		),
		array(
			'id'			=> 'carbohydrate',
			'label'			=> __( 'Total Carbohydrate', 'trg' ),
			'schema'		=> 'carbohydrateContent',
			'liclass'		=> '',
			'labelclass'	=> 'font-bold',
			'sv'			=> apply_filters( 'carbohydrate_sv', 275 ),
			'unit'			=> 'g'
		),
		array(
			'id'			=> 'fiber',
			'label'			=> __( 'Dietary Fiber', 'trg' ),
			'schema'		=> 'fiberContent',
			'liclass'		=> 'nt-sublevel-1',
			'labelclass'	=> '',
			'sv'			=> apply_filters( 'fiber_sv', 28 ),
			'unit'			=> 'g'
		),
		array(
			'id'			=> 'sugar',
			'label'			=> __( 'Total Sugars', 'trg' ),
			'schema'		=> 'sugarContent',
			'liclass'		=> 'nt-sublevel-1',
			'labelclass'	=> '',
			'sv'			=> false,
			'unit'			=> 'g'
		),
		array(
			'id'			=> 'added_sugar',
			'label'			=> __( 'Added Sugars', 'trg' ),
			'schema'		=> false,
			'liclass'		=> 'nt-sublevel-2',
			'labelclass'	=> '',
			'sv'			=> apply_filters( 'added_sugar_sv', 50 ),
			'unit'			=> 'g'
		),
		array(
			'id'			=> 'sugar_alcohal',
			'label'			=> __( 'Sugar Alcohal', 'trg' ),
			'schema'		=> false,
			'liclass'		=> 'nt-sublevel-1',
			'labelclass'	=> '',
			'sv'			=> false,
			'unit'			=> 'g'
		),
		array(
			'id'			=> 'protein',
			'label'			=> __( 'Protein', 'trg' ),
			'schema'		=> 'proteinContent',
			'liclass'		=> 'nt-sep sep-12',
			'labelclass'	=> 'font-bold',
			'sv'			=> apply_filters( 'protein_sv', 50 ),
			'unit'			=> 'g'
		),
		array(
			'id'			=> 'vitamin_d',
			'label'			=> __( 'Vitamin D (Cholecalciferol)', 'trg' ),
			'schema'		=> false,
			'liclass'		=> false,
			'labelclass'	=> false,
			'sv'			=> apply_filters( 'vitamin_d_sv', 800 ),
			'unit'			=> 'IU'
		),
		array(
			'id'			=> 'calcium',
			'label'			=> __( 'Calcium', 'trg' ),
			'schema'		=> false,
			'liclass'		=> false,
			'labelclass'	=> false,
			'sv'			=> apply_filters( 'calcium_sv', 1300 ),
			'unit'			=> 'mg'
		),
		array(
			'id'			=> 'iron',
			'label'			=> __( 'Iron', 'trg' ),
			'schema'		=> false,
			'liclass'		=> false,
			'labelclass'	=> false,
			'sv'			=> apply_filters( 'iron_sv', 18 ),
			'unit'			=> 'mg'
		),
		array(
			'id'			=> 'potassium',
			'label'			=> __( 'Potassium', 'trg' ),
			'schema'		=> false,
			'liclass'		=> false,
			'labelclass'	=> false,
			'sv'			=> apply_filters( 'potassium_sv', 4700 ),
			'unit'			=> 'mg'
		),
		array(
			'id'			=> 'vitamin_a',
			'label'			=> __( 'Vitamin A', 'trg' ),
			'schema'		=> false,
			'liclass'		=> false,
			'labelclass'	=> false,
			'sv'			=> apply_filters( 'vitamin_a_sv', 900 ),
			'unit'			=> 'mcg'
		),
		array(
			'id'			=> 'vitamin_c',
			'label'			=> __( 'Vitamin C (Ascorbic Acid)', 'trg' ),
			'schema'		=> false,
			'liclass'		=> false,
			'labelclass'	=> false,
			'sv'			=> apply_filters( 'vitamin_c_sv', 90 ),
			'unit'			=> 'mg'
		),
		array(
			'id'			=> 'vitamin_e',
			'label'			=> __( 'Vitamin E (Tocopherol)', 'trg' ),
			'schema'		=> false,
			'liclass'		=> false,
			'labelclass'	=> false,
			'sv'			=> apply_filters( 'vitamin_e_sv', 33 ),
			'unit'			=> 'IU'
		),
		array(
			'id'			=> 'vitamin_k',
			'label'			=> __( 'Vitamin K', 'trg' ),
			'schema'		=> false,
			'liclass'		=> false,
			'labelclass'	=> false,
			'sv'			=> apply_filters( 'vitamin_k_sv', 120 ),
			'unit'			=> 'mcg'
		),
		array(
			'id'			=> 'vitamin_b1',
			'label'			=> __( 'Vitamin B1 (Thiamin)', 'trg' ),
			'schema'		=> false,
			'liclass'		=> false,
			'labelclass'	=> false,
			'sv'			=> apply_filters( 'vitamin_b1_sv', 1.2 ),
			'unit'			=> 'mg'
		),
		array(
			'id'			=> 'vitamin_b2',
			'label'			=> __( 'Vitamin B2 (Riboflavin)', 'trg' ),
			'schema'		=> false,
			'liclass'		=> false,
			'labelclass'	=> false,
			'sv'			=> apply_filters( 'vitamin_b2_sv', 1.3 ),
			'unit'			=> 'mg'
		),
		array(
			'id'			=> 'vitamin_b3',
			'label'			=> __( 'Vitamin B3 (Niacin)', 'trg' ),
			'schema'		=> false,
			'liclass'		=> false,
			'labelclass'	=> false,
			'sv'			=> apply_filters( 'vitamin_b3_sv', 16 ),
			'unit'			=> 'mg'
		),
		array(
			'id'			=> 'vitamin_b6',
			'label'			=> __( 'Vitamin B6 (Pyridoxine)', 'trg' ),
			'schema'		=> false,
			'liclass'		=> false,
			'labelclass'	=> false,
			'sv'			=> apply_filters( 'vitamin_b6_sv', 1.7 ),
			'unit'			=> 'mg'
		),
		array(
			'id'			=> 'folate',
			'label'			=> __( 'Folate', 'trg' ),
			'schema'		=> false,
			'liclass'		=> false,
			'labelclass'	=> false,
			'sv'			=> apply_filters( 'folate_sv', 400 ),
			'unit'			=> 'mcg'
		),
		array(
			'id'			=> 'vitamin_b12',
			'label'			=> __( 'Vitamin B12 (Cobalamine)', 'trg' ),
			'schema'		=> false,
			'liclass'		=> false,
			'labelclass'	=> false,
			'sv'			=> apply_filters( 'vitamin_b12_sv', 2.4 ),
			'unit'			=> 'mcg'
		),
		array(
			'id'			=> 'biotin',
			'label'			=> __( 'Biotin', 'trg' ),
			'schema'		=> false,
			'liclass'		=> false,
			'labelclass'	=> false,
			'sv'			=> apply_filters( 'biotin_sv', 30 ),
			'unit'			=> 'mcg'
		),
		array(
			'id'			=> 'choline',
			'label'			=> __( 'Choline', 'trg' ),
			'schema'		=> false,
			'liclass'		=> false,
			'labelclass'	=> false,
			'sv'			=> apply_filters( 'choline_sv', 550 ),
			'unit'			=> 'mg'
		),
		array(
			'id'			=> 'vitamin_b5',
			'label'			=> __( 'Vitamin B5 (Pantothenic acid)', 'trg' ),
			'schema'		=> false,
			'liclass'		=> false,
			'labelclass'	=> false,
			'sv'			=> apply_filters( 'vitamin_b5_sv', 5 ),
			'unit'			=> 'mg'
		),
		array(
			'id'			=> 'phosphorus',
			'label'			=> __( 'Phosphorus', 'trg' ),
			'schema'		=> false,
			'liclass'		=> false,
			'labelclass'	=> false,
			'sv'			=> apply_filters( 'phosphorus_sv', 1250 ),
			'unit'			=> 'mg'
		),
		array(
			'id'			=> 'iodine',
			'label'			=> __( 'Iodine', 'trg' ),
			'schema'		=> false,
			'liclass'		=> false,
			'labelclass'	=> false,
			'sv'			=> apply_filters( 'iodine_sv', 150 ),
			'unit'			=> 'mcg'
		),
		array(
			'id'			=> 'magnesium',
			'label'			=> __( 'Magnesium', 'trg' ),
			'schema'		=> false,
			'liclass'		=> false,
			'labelclass'	=> false,
			'sv'			=> apply_filters( 'magnesium_sv', 420 ),
			'unit'			=> 'mg'
		),
		array(
			'id'			=> 'zinc',
			'label'			=> __( 'Zinc', 'trg' ),
			'schema'		=> false,
			'liclass'		=> false,
			'labelclass'	=> false,
			'sv'			=> apply_filters( 'zinc_sv', 11 ),
			'unit'			=> 'mg'
		),
		array(
			'id'			=> 'selenium',
			'label'			=> __( 'Selenium', 'trg' ),
			'schema'		=> false,
			'liclass'		=> false,
			'labelclass'	=> false,
			'sv'			=> apply_filters( 'selenium_sv', 55 ),
			'unit'			=> 'mcg'
		),
		array(
			'id'			=> 'copper',
			'label'			=> __( 'Copper', 'trg' ),
			'schema'		=> false,
			'liclass'		=> false,
			'labelclass'	=> false,
			'sv'			=> apply_filters( 'copper_sv', .9 ),
			'unit'			=> 'mg'
		),
		array(
			'id'			=> 'manganese',
			'label'			=> __( 'Manganese', 'trg' ),
			'schema'		=> false,
			'liclass'		=> false,
			'labelclass'	=> false,
			'sv'			=> apply_filters( 'manganese_sv', 2.3 ),
			'unit'			=> 'mg'
		),
		array(
			'id'			=> 'chromium',
			'label'			=> __( 'Chromium', 'trg' ),
			'schema'		=> false,
			'liclass'		=> false,
			'labelclass'	=> false,
			'sv'			=> apply_filters( 'chromium_sv', 35 ),
			'unit'			=> 'mcg'
		),
		array(
			'id'			=> 'molybdenum',
			'label'			=> __( 'Molybdenum', 'trg' ),
			'schema'		=> false,
			'liclass'		=> false,
			'labelclass'	=> false,
			'sv'			=> apply_filters( 'molybdenum_sv', 45 ),
			'unit'			=> 'mcg'
		),
		array(
			'id'			=> 'chloride',
			'label'			=> __( 'Chloride', 'trg' ),
			'schema'		=> false,
			'liclass'		=> 'nt-sep',
			'labelclass'	=> false,
			'sv'			=> apply_filters( 'chloride_sv', 2300 ),
			'unit'			=> 'mg'
		)
	) );
		
	/** Start Nutrition table output */
	printf( '<div class="trg nutrition-section%s">',
		$display_style !== 'classic' ? ' ' . esc_attr( $display_style ) : ''
	);
	?>
	
		<ul id="myTable" class="nutrition-table" itemprop="nutrition" itemscope itemtype="http://schema.org/NutritionInformation">
			<?php
			$nutri_json = array( '@type' => 'NutritionInformation', 'calories' => $calories );

			if ( '' !== $nutri_heading ) {
				echo '<li class="nt-header b-0"><h2 class="nt-title">' . esc_html( $nutri_heading ) . '</h2></li>';
			}

			if ( '' !== $serving_per_cont ) {
				printf( '<li class="nt-row b-0 serving-per-cont"><span class="nt-label col-%s">%s</span></li>',						
					'std' == $display_style ? '100' : ( $show_dv ? '80' : '70' ),
					sprintf( __( '%s servings per container', 'trg' ), esc_attr( $serving_per_cont ) ),
					'std' == $display_style ? '50' : ( $show_dv ? '20' : '30' )					
				);

			}			

			if ( '' !== $serving_size ) {
				printf( '<li class="nt-row sep-12 serving-size"><span class="nt-label col-%s">%s</span><span class="nt-value col-%s" itemprop="servingSize">%s</span></li>',
					'std' == $display_style ? '50' : ( $show_dv ? '80' : '70' ),
					__( 'Serving Size', 'trg' ),
					'std' == $display_style ? '50' : ( $show_dv ? '20' : '30' ),						
					esc_attr( $serving_size )
				);
				$nutri_json['servingSize'] = $serving_size;

			}

			printf( '<li class="nt-row b-0 amount-per-serving"><span class="nt-label col-100">%s</span></li>',						
				__( 'Amount per serving', 'trg' )
			);
			
			printf( '<li class="nt-row calories sep-6"><span class="nt-label col-%s">%s</span><span class="nt-value col-%s" itemprop="calories">%s</span></li>',
				$show_dv ? '80' : '70',
				__( 'Calories', 'trg' ),
				$show_dv ? '20' : '30',	
				number_format_i18n( (int)$calories )
			);
			
			if ( $show_dv ) {
				printf( '<li class="nt-row nt-head with-sdv"><span class="nt-label pdv-label col-20">%s</span><span class="sdv-label col-20">%s</span></li>',
					__( '% Daily Value*', 'trg' ),
					__( 'Standard DV', 'trg' )					
				);
			}
			else {
				printf( '<li class="nt-head"><span class="pdv-label col-100 text-right">%s</span></li>',
					__( '% Daily Value*', 'trg' )
				);				
			}

			foreach( $nutrition_facts as $nf ) {

				if ( isset( ${ $nf['id'] } ) && '' !== ${ $nf['id'] } ) {
					// Json LD data
					if ( $json_ld ) {
						if ( $nf['schema'] ) {
							$nutri_json[ $nf['schema'] ] = ${ $nf['id'] } . ' ' . $nf['unit'];
						}
					}
					if ( ! empty( $nf['sv'] ) ) {
						$dv = round( (float)${ $nf['id'] } * 100 / $nf['sv'], 2 );
					}
					if ( $show_dv ) {
						$format = '<li%1$s><span class="nt-label col-40%2$s">%3$s</span><span class="nt-amount col-20"%4$s>%5$s</span>%6$s%7$s</li>';
					}						
					else {
						$format = '<li%1$s><span class="nt-label col-40%2$s">%3$s</span><span class="nt-amount col-30"%4$s>%5$s</span>%7$s</li>';
					}

					printf( $format,
						$nf['liclass'] ? ' class="' . esc_attr( $nf['liclass'] ) . '"' : '',
						$nf['labelclass'] ? ' ' . esc_attr( $nf['labelclass']  ) : '',
						esc_attr( $nf['label'] ),
						$nf['schema']  ?  ' itemprop="' . esc_attr( $nf['schema'] ) . '"' : '',
						${ $nf['id'] } . ' ' . $nf['unit'],
						! empty( $nf['sv'] ) ? sprintf( '<span class="nt-sdv col-20">%s</span>', $nf['sv'] . ' ' . $nf['unit'] ) : '',
						! empty( $nf['sv'] ) ? sprintf( '<span class="nt-value col-%s">%s</span>',
							$show_dv ? '20' : '30',
							(int)$dv <= 100 ? $dv . '%' : '<b>' . $dv . '%</b>'
						) : ''
					);
				}
			}
			
			// Custom Nutrients
			$cust_nutrients = vc_param_group_parse_atts( $custom_nutrients );

			if ( isset( $cust_nutrients ) && is_array( $cust_nutrients ) ) {
				foreach( $cust_nutrients as $cn ) {
	
					if ( isset( $cn['name'] ) && '' !== $cn['name'] ) {
						if ( ! empty( $cn['sv'] ) ) {
							$dv = round( (float)$cn['amt'] * 100 / $cn['sv'], 2 );
						}
						
						if ( $show_dv ) {
							$format = '<li%1$s><span class="nt-label col-40%2$s">%3$s</span><span class="nt-amount col-20">%4$s</span>%5$s%6$s</li>';
						}						
						
						else {
							$format = '<li%1$s><span class="nt-label col-40%2$s">%3$s</span><span class="nt-amount col-30">%4$s</span>%6$s</li>';
						}
	
						printf( $format,
							$cn['level'] !== '0' ? ' class="nt-sublevel-' . esc_attr( $cn['level'] ) . '"' : '',
							isset( $cn['text_style'] ) && 'bold' == $cn['text_style'] ? ' font-bold' : '',
							esc_attr( $cn['name'] ),
							$cn['amt'] . ' ' . $cn['unit'],
							! empty( $cn['sv'] ) ? sprintf( '<span class="nt-sdv col-20">%s</span>', $cn['sv'] . ' ' . $cn['unit'] ) : '',
							! empty( $cn['sv'] ) ? sprintf( '<span class="nt-value col-%s">%s</span>',
								$show_dv ? '20' : '30',
								(int)$dv <= 100 ? $dv . '%' : '<b>' . $dv . '%</b>'
							) : ''
						);
					}
				}
			}			

			if ( '' !== $extra_notes ) {
				printf( '<li class="nt-footer b-0">%s</li>', $extra_notes );
			}
		
		?>
		</ul><!-- /.nutrition-table -->
	</div><!-- /.nutrition-section -->
	<?php
    } // if not hide nutrition facts

    // Add to JSON LD
    $rp_json['nutrition'] = $nutri_json;
	
	// Ad Spot 3
	if ( '' != $ad_spot_3 ) {
		echo '<div class="trg-ad-spot ad-spot-3">' . do_shortcode( rawurldecode( base64_decode( strip_tags( $ad_spot_3 ) ) ) ) . '</div>';
	} elseif ( isset( $ad_spots['ad_spot_3'] ) && '' !== $ad_spots['ad_spot_3'] ) {
		echo '<div class="trg-ad-spot ad-spot-3">' . wp_kses_post( do_shortcode( $ad_spots['ad_spot_3'] ) ) . '</div>';
	}

	// Comments Schema
	$comment_num = get_comments_number();
	$rp_json['interactionStatistic'] = array( '@type' => 'InteractionCounter', 'interactionType' => 'http://schema.org/Comment', 'userInteractionCount' => $comment_num );
	?>
    <div itemprop="interactionStatistic" itemscope itemtype="http://schema.org/InteractionCounter">
        <meta itemprop="interactionType" content="http://schema.org/CommentAction" />
        <meta itemprop="userInteractionCount" content="<?php echo esc_attr( $comment_num ); ?>" />
    </div>

    <?php
	/**
	 * User rating Schema
	 * Requires WP Review plugin
	 *
	 * @uses function mts_get_post_reviews( $post_id )
	 */
	if ( function_exists( 'mts_get_post_reviews' ) ) {
		$rating_arr = mts_get_post_reviews( get_the_id() );
		if ( isset( $rating_arr ) && is_array( $rating_arr ) ) {
			if ( $rating_arr['count'] > 0 && $rating_arr['rating'] > 0 ) {
				?>
				<div itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating">
					<meta itemprop="ratingValue" content="<?php echo $rating_arr['rating']; ?>" />
					<meta itemprop="reviewCount" content="<?php echo $rating_arr['count']; ?>" />
				</div>
				<?php
				$rp_json['aggregateRating'] = array( '@type' => 'AggregateRating', 'ratingValue' => $rating_arr['rating'], 'reviewCount' => $rating_arr['count'] );
			}
        }
	}

	/**
	 * Output JSON LD data as script
	 * Websites like pinterest detect json data better as compared to inline microdata
	 */

	if ( $json_ld ) {
		echo '<script type="application/ld+json">' . json_encode( $rp_json ) . '</script>';
		echo '<script type="application/ld+json">' . json_encode( $website_json ) . '</script>';
	}
	
	/**
	 * Social share buttons
	 */
	if ( is_singular() && ( '' !== $social_buttons || ( isset( $social['social_buttons'] ) && ! empty( $social['social_buttons'] ) ) ) ) {
		$social_sticky = isset( $social['social_sticky'] ) && 'on' == $social['social_sticky'] ? 'true' : $social_sticky;
		if ( '' !== $social_heading || ( isset( $social['social_heading'] ) && '' !== $social['social_heading'] ) ) {
			printf( '<h3 class="trg-social-heading%s">%s</h3>',
				$social_sticky ? ' hide-on-mobile' : '',
				'' !== $social_heading ? esc_attr( $social_heading ) : esc_attr( $social['social_heading'] )
			);
		}
		if ( '' !== $social_buttons ) {
			$share_buttons = explode( ',', $social_buttons );
		} else {
			$share_buttons = $social['social_buttons'];
		}
		if ( is_array( $share_buttons ) && ! empty( $share_buttons ) ) {
			echo '<div class="trg-share-buttons">';
			echo trg_social_sharing( $share_buttons, $social_sticky );
			echo '</div>';
		}
	}
?>
</div><!-- /.trg-recipe -->