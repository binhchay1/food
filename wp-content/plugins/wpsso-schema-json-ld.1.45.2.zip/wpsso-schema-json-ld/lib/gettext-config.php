<?php die( 'These aren\'t the droids you\'re looking for...' );

/**
 * Extract of translatable text strings from the static config array.
 */
_x( 'Schema Markup', 'lib file description', 'wpsso-schema-json-ld' );
_x( 'Schema Shortcode', 'lib file description', 'wpsso-schema-json-ld' );
_x( 'WPSSO Core add-on offers Schema JSON-LD / Rich Results markup for Articles, Events, Local Business, Products, Recipes, Reviews and many more.', 'plugin description', 'wpsso-schema-json-ld' );
