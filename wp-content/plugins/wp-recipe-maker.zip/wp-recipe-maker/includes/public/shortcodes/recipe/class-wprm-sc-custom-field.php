<?php
/**
 * Handle the recipe custom field shortcode.
 *
 * @link       http://bootstrapped.ventures
 * @since      5.2.0
 *
 * @package    WP_Recipe_Maker
 * @subpackage WP_Recipe_Maker/includes/public/shortcodes/recipe
 */

/**
 * Handle the recipe custom field shortcode.
 *
 * @since      5.2.0
 * @package    WP_Recipe_Maker
 * @subpackage WP_Recipe_Maker/includes/public/shortcodes/recipe
 * @author     Brecht Vandersmissen <brecht@bootstrapped.ventures>
 */
class WPRM_SC_Custom_Field extends WPRM_Template_Shortcode {
	public static $shortcode = 'wprm-recipe-custom-field';

	public static function init() {
		self::$attributes = array(
			'id' => array(
				'default' => '0',
			),
			'key' => array(
				'default' => '',
				'type' => 'dropdown',
				'options' => 'custom_fields',
			),
			'text_style' => array(
				'default' => 'normal',
				'type' => 'dropdown',
				'options' => 'text_styles',
			),
			'image_size' => array(
				'default' => 'thumbnail',
				'type' => 'image_size',
			),
		);
		parent::init();
	}

	/**
	 * Output for the shortcode.
	 *
	 * @since	5.2.0
	 * @param	array $atts Options passed along with the shortcode.
	 */
	public static function shortcode( $atts ) {
		$atts = parent::get_attributes( $atts );

		// Show teaser for Premium only shortcode in Template editor.
		if ( ! WPRM_Addons::is_active( 'custom-fields' ) ) {
			if ( ! $atts['is_template_editor_preview'] ) {
				return '';
			} else {
				return '<div class="wprm-template-editor-premium-only">Custom Fields are only available in the <a href="https://bootstrapped.ventures/wp-recipe-maker/get-the-plugin/">WP Recipe Maker Pro Bundle</a>.</div>';
			}
		}

		$recipe = WPRM_Template_Shortcodes::get_recipe( $atts['id'] );
		$value = WPRMPCF_Fields::get( $recipe, $atts['key'] );
		$custom_field_options = WPRMPCF_Manager::get_custom_field( $atts['key'] );
		if ( ! $recipe || ! $value || ! $custom_field_options ) {
			return '';
		}

		// Output.
		$classes = array(
			'wprm-recipe-custom-field',
			'wprm-recipe-custom-field-type-' . $custom_field_options['type'],
			'wprm-recipe-custom-field-key-' . $atts['key'],
			'wprm-block-text-' . $atts['text_style'],
		);

		switch( $custom_field_options['type'] ) {
			case 'email':
				$output = '<a href="mailto:' . esc_attr( $value ). '" class="' . implode( ' ', $classes ) . '">' . $value . '</a>';
				break;
			case 'link':
				$output = '<a href="' . esc_attr( $value ). '" class="' . implode( ' ', $classes ) . '">' . $value . '</a>';
				break;
			case 'text':
				$output = '<span class="' . implode( ' ', $classes ) . '">' . $value . '</span>';
				break;
			case 'textarea':
				$output = '<div class="' . implode( ' ', $classes ) . '">' . do_shortcode( $value ) . '</div>';
				break;
			case 'image':
				if ( $value['id'] ) {
					$output = '<div class="' . implode( ' ', $classes ) . '">' . self::image( $value['id'], $atts['image_size'] ) . '</div>';
				} else {
					$output = '';
				}
				break;
		}

		return apply_filters( parent::get_hook(), $output, $atts, $recipe );
	}


	/**
	 * Output an custom field image.
	 *
	 * @since	5.2.0
	 * @param	mixed $id   ID of the image to output.
	 * @param	mixed $size Image size to use.
	 */
	private static function image( $id, $size ) {
		preg_match( '/^(\d+)x(\d+)$/i', $size, $match );
		if ( ! empty( $match ) ) {
			$size = array( intval( $match[1] ), intval( $match[2] ) );
		}

		$img = wp_get_attachment_image( $id, $size );

		// Prevent instruction image from getting stretched in Gutenberg preview.
		if ( isset( $GLOBALS['wp']->query_vars['rest_route'] ) && '/wp/v2/block-renderer/wp-recipe-maker/recipe' === $GLOBALS['wp']->query_vars['rest_route'] ) {
			$image_data = wp_get_attachment_image_src( $id, $size );
			if ( $image_data[1] ) {
				$style .= 'max-width: ' . $image_data[1] . 'px;';

				if ( false !== stripos( $img, ' style="' ) ) {
					$img = str_ireplace( ' style="', ' style="' . $style, $img );
				} else {
					$img = str_ireplace( '<img ', '<img style="' . $style . '" ', $img );
				}
			}
		}

		return $img;
	}
}

WPRM_SC_Custom_Field::init();