<?php
/**
 * Handle the recipe equipment shortcode.
 *
 * @link       http://bootstrapped.ventures
 * @since      3.3.0
 *
 * @package    WP_Recipe_Maker
 * @subpackage WP_Recipe_Maker/includes/public/shortcodes/recipe
 */

/**
 * Handle the recipe equipment shortcode.
 *
 * @since      3.3.0
 * @package    WP_Recipe_Maker
 * @subpackage WP_Recipe_Maker/includes/public/shortcodes/recipe
 * @author     Brecht Vandersmissen <brecht@bootstrapped.ventures>
 */
class WPRM_SC_Equipment extends WPRM_Template_Shortcode {
	public static $shortcode = 'wprm-recipe-equipment';

	public static function init() {
		self::$attributes = array(
			'id' => array(
				'default' => '0',
			),
			'text_style' => array(
				'default' => 'normal',
				'type' => 'dropdown',
				'options' => 'text_styles',
			),
			'header' => array(
				'default' => '',
				'type' => 'text',
			),
			'header_tag' => array(
				'default' => 'h3',
				'type' => 'dropdown',
				'options' => 'header_tags',
				'dependency' => array(
					'id' => 'header',
					'value' => '',
					'type' => 'inverse',
				),
			),
			'header_style' => array(
				'default' => 'bold',
				'type' => 'dropdown',
				'options' => 'text_styles',
				'dependency' => array(
					'id' => 'header',
					'value' => '',
					'type' => 'inverse',
				),
			),
			'list_style' => array(
				'default' => 'disc',
				'type' => 'dropdown',
				'options' => 'list_style_types',
			),
			'text_margin' => array(
				'default' => '0px',
				'type' => 'size',
			),
		);
		parent::init();
	}

	/**
	 * Output for the shortcode.
	 *
	 * @since	3.3.0
	 * @param	array $atts Options passed along with the shortcode.
	 */
	public static function shortcode( $atts ) {
		$atts = parent::get_attributes( $atts );

		$recipe = WPRM_Template_Shortcodes::get_recipe( $atts['id'] );
		if ( ! $recipe || ! $recipe->equipment() ) {
			return '';
		}

		// Output.
		$classes = array(
			'wprm-recipe-equipment-container',
			'wprm-block-text-' . $atts['text_style'],
		);

		$output = '<div class="' . implode( ' ', $classes ) . '">';

		if ( $atts['header'] ) {
			$classes = array(
				'wprm-recipe-header',
				'wprm-recipe-equipment-header',
				'wprm-block-text-' . $atts['header_style'],
			);

			$tag = trim( $atts['header_tag'] );
			$output .= '<' . $tag . ' class="' . implode( ' ', $classes ) . '">' . __( $atts['header'], 'wp-recipe-maker' ) . '</' . $tag . '>';
		}

		$output .= '<ul class="wprm-recipe-equipment">';
		foreach ( $recipe->equipment() as $equipment ) {
			$list_style_type = 'checkbox' === $atts['list_style'] ? 'none' : $atts['list_style'];
			$style = 'list-style-type: ' . $list_style_type . ';';
			$output .= '<li class="wprm-recipe-equipment-item" style="' . $style . '">';

			// Output checkbox.
			if ( 'checkbox' === $atts['list_style'] && WPRM_Addons::is_active( 'premium' ) ) {
				$output .= WPRMP_Checkboxes::checkbox();
			}

			// Equipment link.
			$name = $equipment['name'];
			if ( WPRM_Addons::is_active( 'premium' ) && isset( $equipment['id'] ) && $equipment['id'] ) {
				$link = get_term_meta( $equipment['id'], 'wprmp_equipment_link', true );
				$link_nofollow = get_term_meta( $equipment['id'], 'wprmp_equipment_link_nofollow', true );

				if ( $link ) {
					$target = WPRM_Settings::get( 'equipment_links_open_in_new_tab' ) ? ' target="_blank"' : '';

					// Nofollow.
					switch ( $link_nofollow ) {
						case 'follow':
							$nofollow = '';
							break;
						case 'nofollow':
							$nofollow = ' rel="nofollow"';
							break;
						default:
							$nofollow = WPRM_Settings::get( 'ingredient_links_use_nofollow' ) ? ' rel="nofollow"' : '';
					}

					$name = '<a href="' . $link . '"' . $target . $nofollow . '>' . $name . '</a>';
				}
			}

			$output .= '<div class="wprm-recipe-equipment-name">' . $name . '</div>';
			$output .= '</li>';
		}
		$output .= '</ul>';
		$output .= '</div>';

		return apply_filters( parent::get_hook(), $output, $atts, $recipe );
	}
}

WPRM_SC_Equipment::init();