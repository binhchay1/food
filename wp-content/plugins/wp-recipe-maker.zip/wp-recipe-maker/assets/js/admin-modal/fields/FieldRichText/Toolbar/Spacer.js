import React from 'react';

const Spacer = (props) => {
	return (
		<span className="wprm-admin-modal-toolbar-spacer"></span>
	);
}
export default Spacer;