import React from 'react';

import '../../../css/admin/template/loader.scss';

const Loader = (props) => {
    return (
        <div className="wprm-template-loader"></div>
    );
}
export default Loader;