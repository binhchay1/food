
if (!global._babelPolyfill) { require('babel-polyfill'); }
import './public/comment-rating';
import './public/print';

import '../css/public/comments.scss';
import '../css/public/print.scss';
import '../css/public/snippets.scss';
import '../css/public/template_reset.scss';

// For roundup template in Legacy mode.
import '../css/shortcodes/_spacer.scss';