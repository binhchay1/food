import React from 'react';

import '../../css/admin/shared/loader.scss';

const Loader = (props) => {
    return (
        <div className="wprm-admin-loader"></div>
    );
}
export default Loader;