export function __wprm( text, domain = 'wp-recipe-maker' ) {
    if ( wprm_admin_modal.translations.hasOwnProperty( text ) ) {
        return wprm_admin_modal.translations[ text ];
    } else {
        return text;
    }
};
