if (!global._babelPolyfill) { require('babel-polyfill'); }
import './admin/editor';
import './admin/feedback';
import './admin/import';
import './admin/settings';
import './admin/tools';

import '../css/admin/addons.scss';
import '../css/admin/comments.scss';
import '../css/admin/faq.scss';

import './public/comment-rating';